/* Header top row: lines the address and icons up with the logo and phone button below them. */
(function () {
  function run() {
    var tb = document.querySelector(".ags-tb"); if (!tb) return;
    var inn = tb.querySelector(".ags-tb-in"), L = tb.getAttribute("data-align-left"), R = tb.getAttribute("data-align-right");
    if (tb.classList.contains("ags-tb--fixed")) document.documentElement.classList.add("ags-tb-on");
    function vis(e) { return e && e.offsetWidth > 0 && e.getClientRects().length; }
    function align() {
      var l = L && document.querySelector(L), r = R && document.querySelector(R);
      if (!vis(l) || !vis(r)) { inn.style.paddingLeft = inn.style.paddingRight = ""; return; }
      var t = tb.getBoundingClientRect(), lr = l.getBoundingClientRect(), rr = r.getBoundingClientRect();
      inn.style.paddingLeft = Math.max(12, Math.round(lr.left - t.left)) + "px";
      inn.style.paddingRight = Math.max(12, Math.round(t.right - rr.right)) + "px";
    }
    var tm; function later() { clearTimeout(tm); tm = setTimeout(align, 80); }
    align(); addEventListener("resize", later); addEventListener("load", align);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(align);
    setTimeout(align, 700); setTimeout(align, 2000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run); else run();
})();
