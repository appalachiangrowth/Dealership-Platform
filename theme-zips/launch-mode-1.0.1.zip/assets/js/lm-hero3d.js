/* Launch Mode: pinned 3D hero (Toyota Fortuner 2021 by Asadawut.Kaewma, sketchfab.com/3d-models/toyota-fortuner-2021-a70b997f11b7482e9affbf318a508f85, licensed CC-BY-4.0; simplified for the web).
   Scroll drives 5 stages: Arrival -> Close-up -> Exploded view -> Reassembly -> Launch.
   Stage copy comes from the template (editable in the site editor); colours follow the theme's design settings.
   Optional: set window.LAUNCH_CAR={paint:"#0d0e12",rims:"#14161a",exposure:.8} before this script to restyle the car. */
(function(){
var el=document.getElementById('cv');if(!el)return;
var $=function(s){return document.querySelector(s)};
var CAR=window.LAUNCH_CAR||window.VELOCITY_CAR||{};
/* car look; any key can be overridden via window.LAUNCH_CAR (paint, metal, rough, coat, coatRough, env, envAll, exposure, light, top) */
var LOOK={paint:CAR.paint||'#eceef1',metal:CAR.metal!=null?CAR.metal:.08,rough:CAR.rough!=null?CAR.rough:.22,coat:CAR.coat!=null?CAR.coat:1,coatRough:CAR.coatRough!=null?CAR.coatRough:.05,env:CAR.env!=null?CAR.env:1,envAll:CAR.envAll!=null?CAR.envAll:.9,ao:CAR.ao!=null?CAR.ao:.3,exposure:CAR.exposure||.85,light:CAR.light!=null?CAR.light:.45,top:CAR.top!=null?CAR.top:2.5,strip:CAR.strip!=null?CAR.strip:10};
var CSSV=function(n,f){try{var v=getComputedStyle(document.documentElement).getPropertyValue(n).trim();return v||f}catch(e){return f}};
var C={paint:CAR.paint||null,accent:CAR.accent||CSSV('--sodium','#e0563f'),calipers:CAR.calipers||CSSV('--ion','#d174d2'),rims:CAR.rims||'#14161a',shine:CAR.shine==null?.35:CAR.shine};
var STG=[['Arrival','Rolling onto the showroom floor.'],['Close-up','Every line, every detail, up close.'],['Exploded view','Every single part, laid bare.'],['Reassembly','Back together, piece by piece.'],['Launch','Wheels spin. Then it\'s gone.']];
/* stage titles/lines from data-s1..data-s5 ("Title|Line") on #cv, set by the template */
for(var si=0;si<5;si++){var sv=el.getAttribute('data-s'+(si+1));if(sv&&sv.indexOf('{%')<0){var sp=sv.split('|');STG[si]=[sp[0].trim()||STG[si][0],(sp[1]||'').trim()||STG[si][1]]}}
var LBL={load:el.getAttribute('data-loading')||'LOADING 3D',ready:el.getAttribute('data-ready')||'SCROLL TO DRIVE \u00b7 DRAG TO ROTATE'};
var cl=function(x){return x<0?0:x>1?1:x},seg=function(p,a,b){return cl((p-a)/(b-a))},lr=function(a,b,t){return a+(b-a)*t},eo=function(t){return 1-Math.pow(1-t,3)},eio=function(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2};
var hn=$('#hn'),lb=$('#lb'),lbar=$('#lbar');
function prog(x){if(hn&&hn.getAttribute('data-l')!=='0'){hn.setAttribute('data-l','1');hn.textContent=LBL.load+' '+Math.round(x*100)+'%'};if(lb)lb.style.transform='scaleX('+x+')'}
function TL(p,I){var a=I,z=seg(p,.02,.2),x=seg(p,.2,.44),h=seg(p,.44,.52),r=seg(p,.52,.72),s=seg(p,.72,.84),l=seg(p,.84,1),Z=eio(z),X=eio(x),Rr=eio(r);
return{a:a,s:s,l:l,e:X*(1-Rr),yaw:lr(1.5,.6,eo(a))+.55*Z+.85*X+.3*h+(Math.PI/2-2.3)*Rr,
 cd:lr(lr(lr(8.6,5.3,Z),12.8,X),8.8,Rr),cy:lr(lr(lr(1.7,1.05,Z),3.7,X),1.45,Rr),ly:lr(lr(lr(.7,.5,Z),1.35,X),.6,Rr),
 dist:-11*(1-eo(a))+30*Math.pow(l,2.2),stage:p<.02?0:p<.2?1:p<.52?2:p<.72?3:4}}
if(!window.THREE){if(hn)hn.textContent='';el.classList.add('no3d');return}
var T=THREE,r;
try{r=new T.WebGLRenderer({antialias:true,alpha:true,logarithmicDepthBuffer:true})}catch(e){if(hn)hn.textContent='';el.classList.add('no3d');return}
r.setClearColor(0x000000,0);r.setPixelRatio(innerWidth<900?Math.min(devicePixelRatio,1.5):Math.min(Math.max(devicePixelRatio,1.5),2));r.outputEncoding=T.sRGBEncoding;r.toneMapping=T.ACESFilmicToneMapping;r.toneMappingExposure=LOOK.exposure;el.prepend(r.domElement);
var sc=new T.Scene(),cam=new T.PerspectiveCamera(34,1,.1,100),pv=new T.Group(),hold=new T.Group(),es=new T.Scene();pv.rotation.y=.6;pv.add(hold);sc.add(pv);es.background=new T.Color(0x1a1a20);
(function(){var dg=new T.SphereGeometry(30,48,24),col=[],pa=dg.attributes.position,c=new T.Color();for(var i=0;i<pa.count;i++){var y=pa.getY(i)/30,t=y>0?Math.pow(y,.6):0;c.setRGB(.05+.55*t,.05+.55*t,.06+.6*t);if(y<0)c.setRGB(.035,.035,.04);col.push(c.r,c.g,c.b)}dg.setAttribute('color',new T.Float32BufferAttribute(col,3));es.add(new T.Mesh(dg,new T.MeshBasicMaterial({vertexColors:true,side:T.BackSide})));
 function pl(w,h,x,y,z,rx,ry,k){var m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({color:new T.Color(1,1,1).multiplyScalar(k),side:T.DoubleSide}));m.position.set(x,y,z);m.rotation.set(rx,ry,0);es.add(m)}
 pl(9,5,0,8,0,Math.PI/2,0,LOOK.top);pl(.7,10,9,3.2,0,0,Math.PI/2,LOOK.strip);pl(.7,10,-9,3.2,0,0,Math.PI/2,LOOK.strip);pl(10,.6,0,3,-9,0,0,LOOK.strip*.7);pl(10,.6,0,2.4,9,0,Math.PI,LOOK.strip*.5)})();
sc.environment=new T.PMREMGenerator(r).fromScene(es,.015).texture;var dl=new T.DirectionalLight(0xffffff,LOOK.light);dl.position.set(4,8,5);sc.add(dl);
var ring=new T.Mesh(new T.RingGeometry(3.3,3.36,72),new T.MeshBasicMaterial({color:new T.Color(C.calipers),side:2,transparent:true}));ring.rotation.x=-Math.PI/2;ring.position.y=.01;sc.add(ring);
var sk=document.createElement('canvas');sk.width=sk.height=128;var cx=sk.getContext('2d'),gr=cx.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(65,38,83,.42)');gr.addColorStop(1,'rgba(0,0,0,0)');cx.fillStyle=gr;cx.fillRect(0,0,128,128);
var sh=new T.Mesh(new T.PlaneGeometry(3.4,6.2),new T.MeshBasicMaterial({map:new T.CanvasTexture(sk),transparent:true,depthWrite:false}));sh.rotation.x=-Math.PI/2;sh.position.y=.004;pv.add(sh);
var dg=new T.BufferGeometry(),dp=new Float32Array(900);for(var i=0;i<900;i+=3){dp[i]=(Math.random()-.5)*22;dp[i+1]=Math.random()*7;dp[i+2]=(Math.random()-.5)*14}dg.setAttribute('position',new T.BufferAttribute(dp,3));
var dust=new T.Points(dg,new T.PointsMaterial({color:new T.Color(C.accent),size:.035,transparent:true,opacity:.55,depthWrite:false}));sc.add(dust);
var SMOOTH=.16,INTRO=.012; /* SMOOTH: higher = car follows scroll faster (was .085). INTRO: arrival speed per frame (was .0068) */
var S={uy:0,sp:0,I:0,car:null,stg:-1,k:1,force:1},dn=0,lx=0;
el.onpointerdown=function(e){dn=1;lx=e.clientX;try{el.setPointerCapture(e.pointerId)}catch(x){}};
el.onpointermove=function(e){if(dn){S.uy+=(e.clientX-lx)*.01;lx=e.clientX}};el.onpointerup=el.onpointercancel=function(){dn=0};
function rs(){S.force=1;var w=el.clientWidth,h=el.clientHeight;if(!w||!h)return;r.setSize(w,h);cam.aspect=w/h;S.k=w/h<1?1.5:1;cam.position.set(0,1.7,w/h<1?13:8.6);cam.lookAt(0,.7,0);cam.updateProjectionMatrix()}
addEventListener('resize',rs);rs();
var stk=$('#stk');if(stk)for(var q=0;q<16;q++){var o=document.createElement('i');o.style.cssText='top:'+(8+Math.random()*84)+'%;width:'+(20+Math.random()*30)+'%;animation-delay:'+(-Math.random()*.5)+'s;animation-duration:'+(.3+Math.random()*.4)+'s;opacity:'+(.3+Math.random()*.7);stk.appendChild(o)}
/* ---------- build the car from the GLB (Z-up, nose +X) ---------- */
function mat(n){
 var M=function(o){return new T.MeshStandardMaterial(o)};
 if(/calip/i.test(n))return M({color:C.calipers,metalness:.3,roughness:.4});
 if(/orange/i.test(n))return M({color:C.accent,metalness:.3,roughness:.4});
 if(/Main_white_body/i.test(n))return M({color:C.paint||0xeeede5,metalness:.35,roughness:1-C.shine*.8});
 if(/Glass_canopy|Windshield|Rear_glass|Side_window/i.test(n))return M({color:0x16222f,metalness:.9,roughness:.06,transparent:true,opacity:.62,depthWrite:false});
 if(/LED_head/i.test(n))return M({color:0xcddae4,emissive:0xcddae4,emissiveIntensity:.6,metalness:.2,roughness:.2});
 if(/light_bar/i.test(n))return M({color:0xbe1c19,emissive:0xbe1c19,emissiveIntensity:.9});
 if(/tire/i.test(n))return M({color:0x0c0d0f,metalness:0,roughness:.92});
 if(/alloy_wheel/i.test(n))return M({color:C.rims,metalness:.85,roughness:.3});
 if(/disc|exhaust/i.test(n))return M({color:0x697078,metalness:.9,roughness:.35});
 return M({color:0x121417,metalness:.3,roughness:.5});
}
function dirFor(n,c,sg){ /* explode direction (GLB axes: x=nose, y=side, z=up) and distance */
 var d,k;
 if(/_tire_/i.test(n)||/^(front|rear)_tire/i.test(n)){d=[0,sg,0];k=.7}
 else if(/alloy_wheel/i.test(n)){d=[0,sg,.04];k=1.2}
 else if(/brake_disc/i.test(n)){d=[0,sg,.06];k=1.7}
 else if(/rim_ring/i.test(n)){d=[0,sg,.08];k=2.1}
 else if(/center_hub/i.test(n)){d=[0,sg,.1];k=2.5}
 else if(/caliper/i.test(n)){d=[0,sg,.35];k=1.9}
 else if(/Main_white_body/i.test(n)){d=[0,0,1];k=2.1}
 else if(/Underbody|diffuser|splitter/i.test(n)){d=[/splitter/i.test(n)?1:/diffuser/i.test(n)?-1:0,0,-1];k=1.5}
 else if(/Glass_canopy|Windshield|Rear_glass/i.test(n)){d=[0,0,1];k=1.3+Math.abs(c.x)*.2}
 else if(/Rear_wing|Wing_support/i.test(n)){d=[-.8,0,.7];k=1.9}
 else if(/exhaust|light_bar/i.test(n)){d=[-1,0,.1];k=1.7}
 else if(/seat|Dashboard|Steering/i.test(n)){d=[0,0,1];k=.9+Math.abs(c.x)*.4}
 else if(/skirt/i.test(n)){d=[0,sg,-.2];k=1.5}
 else{d=[c.x*.6,c.y*1.2||sg*.3,c.z-.9+.4];k=1.4}
 var v=new T.Vector3(d[0],d[1],d[2]).normalize();return v.multiplyScalar(k)}
/* The GLB has no NORMAL data, so any lit material renders black. Build creased (smooth-but-keeps-hard-edges) normals here. */
function creased(g){if(g.attributes.normal)return g;
 var ng=g.index?g.toNonIndexed():g,p=ng.attributes.position.array,n=p.length/9,fn=new Float32Array(n*3),map={},out=new Float32Array(p.length),i,j,f,k,o,x,y,z,L,
 a=new T.Vector3(),b=new T.Vector3(),c=new T.Vector3(),key=function(q){return Math.round(p[q]*1e4)+','+Math.round(p[q+1]*1e4)+','+Math.round(p[q+2]*1e4)};
 for(i=0;i<n;i++){a.fromArray(p,i*9);b.fromArray(p,i*9+3);c.fromArray(p,i*9+6);c.sub(b);b.sub(a);b.cross(c).normalize();fn[i*3]=b.x;fn[i*3+1]=b.y;fn[i*3+2]=b.z;
  for(j=0;j<3;j++){k=key(i*9+j*3);(map[k]=map[k]||[]).push(i)}}
 for(i=0;i<n;i++)for(j=0;j<3;j++){var l=map[key(i*9+j*3)];x=y=z=0;
  for(f=0;f<l.length;f++){o=l[f]*3;if(fn[i*3]*fn[o]+fn[i*3+1]*fn[o+1]+fn[i*3+2]*fn[o+2]>.766){x+=fn[o];y+=fn[o+1];z+=fn[o+2]}}
  L=Math.sqrt(x*x+y*y+z*z)||1;o=i*9+j*3;out[o]=x/L;out[o+1]=y/L;out[o+2]=z/L}
 ng.setAttribute('normal',new T.BufferAttribute(out,3));return ng}
/* Smooth exterior: the GLB ships 8-bit normals (127 steps), which show as faceted, stepped reflections on the glossy paint.
   Rebuild full-precision normals: weld vertices that share a position, sum the area-weighted face normals around them,
   and only blend faces within ~60 degrees of the authored normal, so real body creases stay crisp while curved panels go smooth. */
function smoothN(g){var P=g.attributes.position,N=g.attributes.normal;if(!P||!N||!g.index)return g;
 var n=P.count,pa=P.array,ix=g.index.array,tn=ix.length/3,on=N.array,i,j,k,a,b,c;
 g.computeBoundingBox();var bb=g.boundingBox,q=Math.max(bb.max.x-bb.min.x,bb.max.y-bb.min.y,bb.max.z-bb.min.z)*2e-6||1e-6;
 var grp=new Int32Array(n),map=new Map(),gc=0;
 for(i=0;i<n;i++){var key=Math.round(pa[i*3]/q)+'_'+Math.round(pa[i*3+1]/q)+'_'+Math.round(pa[i*3+2]/q),v=map.get(key);if(v===undefined){v=gc++;map.set(key,v)}grp[i]=v}
 map=null;
 var fnm=new Float32Array(tn*3),cnt=new Int32Array(gc+1);
 for(i=0;i<tn;i++){a=ix[i*3];b=ix[i*3+1];c=ix[i*3+2];
  var ax=pa[a*3],ay=pa[a*3+1],az=pa[a*3+2],ux=pa[b*3]-ax,uy=pa[b*3+1]-ay,uz=pa[b*3+2]-az,vx=pa[c*3]-ax,vy=pa[c*3+1]-ay,vz=pa[c*3+2]-az;
  fnm[i*3]=uy*vz-uz*vy;fnm[i*3+1]=uz*vx-ux*vz;fnm[i*3+2]=ux*vy-uy*vx;
  cnt[grp[a]+1]++;cnt[grp[b]+1]++;cnt[grp[c]+1]++}
 for(i=0;i<gc;i++)cnt[i+1]+=cnt[i];
 var fill=cnt.slice(0,gc),lst=new Int32Array(cnt[gc]);
 for(i=0;i<tn;i++)for(j=0;j<3;j++){k=grp[ix[i*3+j]];lst[fill[k]++]=i}
 var out=new Float32Array(n*3),s=1/127;
 for(i=0;i<n;i++){var ox=on[i*3],oy=on[i*3+1],oz=on[i*3+2],ol=Math.sqrt(ox*ox+oy*oy+oz*oz)||1;ox/=ol;oy/=ol;oz/=ol;
  var x=0,y=0,z=0,G=grp[i];
  for(k=cnt[G];k<cnt[G+1];k++){var f=lst[k]*3,fx=fnm[f],fy=fnm[f+1],fz=fnm[f+2],fl=Math.sqrt(fx*fx+fy*fy+fz*fz);if(!fl)continue;
   if((fx*ox+fy*oy+fz*oz)/fl>.5){x+=fx;y+=fy;z+=fz}}
  var L=Math.sqrt(x*x+y*y+z*z);if(L>0){out[i*3]=x/L;out[i*3+1]=y/L;out[i*3+2]=z/L}else{out[i*3]=ox;out[i*3+1]=oy;out[i*3+2]=oz}}
 g.setAttribute('normal',new T.BufferAttribute(out,3));return g}
/* Fortuner (Sketchfab, Y-up, nose +Z, nested node transforms): bake every mesh into flat Z-up/nose+X parts so the Porsche pipeline below works unchanged */
function fdir(o,c,sg,W){
 var mn=o.material&&o.material.name||'',n=o.name,d,k;
 if(W){d=[0,sg,/tire/i.test(mn)?0:.05];k=/tire/i.test(mn)?.8:/rim|material$/i.test(mn)?1.3:1.8}
 else if(/glass|window/i.test(mn)){d=[0,0,1];k=1.3+Math.abs(c.x)*.15}
 else if(/seat|leather|int$|_int|plastic_1|plastic_egg|stitch|seatbelt/i.test(mn)){d=[c.x*.15,c.y*.6,1.2];k=.9+Math.abs(c.x)*.25}
 else if(/tailight|tailighjt|light/i.test(mn)){d=[c.x<0?-1:1,0,.2];k=1.5}
 else if(/carpaint|Material_4$/i.test(mn)){d=[c.x*.35,c.y*1.4||sg*.4,.55+Math.max(0,c.z-.6)*.6];k=1.9}
 else{d=[c.x*.4,c.y*1.2||sg*.3,.4+Math.max(0,c.z-.5)*.5];k=1.5}
 return new T.Vector3(d[0],d[1],d[2]).normalize().multiplyScalar(k)}
function deq(g){Object.keys(g.attributes).forEach(function(k){var a=g.attributes[k];if(!a.normalized)return;var ar=a.isInterleavedBufferAttribute?a.data.array:a.array;if(ar instanceof Float32Array)return;
 var m=ar instanceof Int8Array?127:ar instanceof Uint8Array?255:ar instanceof Int16Array?32767:65535,sg=ar instanceof Int8Array||ar instanceof Int16Array,n=a.count,s=a.itemSize,f=new Float32Array(n*s),gt=[a.getX,a.getY,a.getZ,a.getW];
 for(var i=0;i<n;i++)for(var c=0;c<s;c++){var v=gt[c].call(a,i)/m;f[i*s+c]=sg&&v<-1?-1:v}
 g.setAttribute(k,new T.BufferAttribute(f,s))});return g}
function buildFortuner(gltf){
 var src=gltf.scene,parts=[],flat=new T.Group(),tr=0,P=new T.Matrix4().set(0,0,1,0, 1,0,0,0, 0,1,0,0, 0,0,0,1);
 src.updateMatrixWorld(true);
 src.traverse(function(o){if(!o.isMesh)return;
  var wheel=false,q=o.parent;while(q){if(/^WHEEL_/i.test(q.name)){wheel=true;break}q=q.parent}
  var g=deq(o.geometry.clone()),m4=P.clone().multiply(o.matrixWorld),neg=o.matrixWorld.determinant()<0;g.applyMatrix4(m4);
  if(neg&&g.index){var ix=g.index.array;for(var i=0;i<ix.length;i+=3){var t=ix[i];ix[i]=ix[i+2];ix[i+2]=t}}
  smoothN(g);g.computeBoundingBox();var c=g.boundingBox.getCenter(new T.Vector3());g.translate(-c.x,-c.y,-c.z);
  var mt=o.material;if(mt&&!mt.userData._f){mt.userData._f=1;var nm=mt.name||'';mt.envMapIntensity=LOOK.envAll;if(mt.aoMap&&/^(chrome|black|grey|Material_4)$/i.test(nm))mt.aoMapIntensity=.55;
   /* dark paint, black rims, tinted glass */
   if(/^carpaint$/i.test(nm)){if(LOOK.paint)mt.color.set(LOOK.paint);mt.metalness=LOOK.metal;mt.roughness=LOOK.rough;mt.metalnessMap=null;mt.roughnessMap=null;mt.aoMapIntensity=LOOK.ao;if(mt.clearcoat!==undefined){mt.clearcoat=LOOK.coat;mt.clearcoatRoughness=LOOK.coatRough}mt.envMapIntensity=LOOK.env}
   else if(/^material$/i.test(nm)){mt.color.set(C.rims);mt.map=null;mt.metalness=.8;mt.roughness=.32}
   else if(wheel&&/^(chrome|chrome_only|Material_18|Material_4)$/i.test(nm)){mt.color.set(0x0b0c0e);mt.map=null;mt.metalness=.8;mt.roughness=.35}
   else if(/^windows_glass$/i.test(nm)){mt.color.set(0x030508);mt.map=null;mt.transparent=true;mt.opacity=.88;mt.metalness=.6;mt.roughness=.06;mt.depthWrite=false}
   else if(/^glass_decal$/i.test(nm)){mt.color.set(0x030508);mt.transparent=true;mt.opacity=.55;mt.depthWrite=false}}
  var mh=new T.Mesh(g,mt);mh.position.copy(c);flat.add(mh);
  var sg=c.y<0?-1:1,isTire=wheel&&/tire/i.test(mt&&mt.name||'');
  if(isTire){var bb2=g.boundingBox;tr=Math.max(tr,(bb2.max.x-bb2.min.x)/2)}
  parts.push({m:mh,base:c.clone(),off:fdir(mh,c,sg,wheel),tum:new T.Vector3((Math.random()-.5)*.7,(Math.random()-.5)*.7,(Math.random()-.5)*.7),spin:wheel})});
 src.traverse(function(o){if(o.isMesh){o.geometry.dispose()}});
 return finish(flat,parts,tr)}
function finish(root,parts,R){
 var inner=new T.Group();inner.add(root);root.rotation.x=-Math.PI/2;
 var w=new T.Group();w.add(inner);w.rotation.y=-Math.PI/2;
 var out=new T.Group();out.add(w);
 var bb=new T.Box3().setFromObject(out),z=bb.getSize(new T.Vector3()),sc2=4.6/Math.max(z.x,z.z);out.scale.multiplyScalar(sc2);out.updateMatrixWorld(true);bb.setFromObject(out);var ce=bb.getCenter(new T.Vector3());
 var hol=new T.Group();hol.add(out);out.position.set(-ce.x,-bb.min.y,-ce.z);
 hol.userData.R=R?R*sc2:.49;
 hol.userData.set=function(e,roll){parts.forEach(function(p){var m=p.m;m.position.set(p.base.x+p.off.x*e,p.base.y+p.off.y*e,p.base.z+p.off.z*e);m.rotation.set(p.tum.x*e,p.tum.y*e+(p.spin?roll:0),p.tum.z*e)})};
 return hol}
function build(gltf){
 if(gltf.scene.getObjectByName('Sketchfab_model'))return buildFortuner(gltf);
 var root=gltf.scene,parts=[];
 root.traverse(function(o){if(!o.isMesh)return;o.geometry=creased(o.geometry);var g=o.geometry;g.computeBoundingBox();var c=g.boundingBox.getCenter(new T.Vector3());g.translate(-c.x,-c.y,-c.z);o.position.copy(c);o.material=mat(o.name);o.castShadow=false;
  var sg=c.y<0?-1:1,spin=/(tire|alloy_wheel|rim_ring|brake_disc|center_hub)/i.test(o.name);
  var rnd=function(){return Math.random()-.5};
  parts.push({m:o,base:c.clone(),off:dirFor(o.name,c,sg),tum:new T.Vector3(rnd()*.7,rnd()*.7,rnd()*.7),spin:spin})});
 var inner=new T.Group();inner.add(root);root.rotation.x=-Math.PI/2;
 var w=new T.Group();w.add(inner);w.rotation.y=-Math.PI/2;
 var out=new T.Group();out.add(w);
 var bb=new T.Box3().setFromObject(out),z=bb.getSize(new T.Vector3());out.scale.multiplyScalar(4.6/Math.max(z.x,z.z));out.updateMatrixWorld(true);bb.setFromObject(out);var ce=bb.getCenter(new T.Vector3());
 var hol=new T.Group();hol.add(out);out.position.set(-ce.x,-bb.min.y,-ce.z);
 hol.userData.R=.49;
 hol.userData.set=function(e,roll){parts.forEach(function(p){var m=p.m;m.position.set(p.base.x+p.off.x*e,p.base.y+p.off.y*e,p.base.z+p.off.z*e);m.rotation.set(p.tum.x*e,p.tum.y*e+(p.spin?roll:0),p.tum.z*e)})};
 return hol}
function onFail(){if(hn){hn.setAttribute('data-l','0');hn.textContent=''}if(lbar)lbar.classList.add('done');el.classList.add('no3d')}
function ready(g){prog(1);var car=build(g);hold.add(car);S.car=car.userData;S.car.set(0,0);S.force=1;if(lbar)lbar.classList.add('done');if(hn){hn.setAttribute('data-l','0');hn.textContent=LBL.ready}}
/* the hero is the first screen, so the model starts loading right away (progress bar under the car) */
function go(){if(!T.GLTFLoader){onFail();return}new T.GLTFLoader().load(el.getAttribute('data-glb'),ready,function(x){if(x.total)prog(x.loaded/x.total)},onFail)}
prog(0);go();
var pin=$('#pin'),rail=[].slice.call(document.querySelectorAll('#rail i')),kmh=$('#kmh'),LK='';
if(matchMedia('(prefers-reduced-motion:reduce)').matches)S.I=1;
var PT=0;
/* iOS memory / battery guard: the hero loop sleeps while the hero is off screen or the tab is hidden (one loop at a time) */
var lmVis=true,lmRun=false;function lmKick(){if(!lmRun&&lmVis&&!document.hidden){lmRun=true;PT=0;requestAnimationFrame(lp)}}
if('IntersectionObserver' in window)new IntersectionObserver(function(es){lmVis=es[0].isIntersecting;lmKick()},{rootMargin:'120px 0px'}).observe(pin);
document.addEventListener('visibilitychange',lmKick);
function lp(t){if(!lmVis||document.hidden){lmRun=false;return}requestAnimationFrame(lp);t=t||0;var dt=PT?Math.min(3,(t-PT)/16.667):1;PT=t; /* dt = frames elapsed (1 @60fps) so speed is same on 60/120Hz */
 var b=pin.getBoundingClientRect(),tp=cl(-b.top/Math.max(1,b.height-innerHeight));S.sp+=(tp-S.sp)*(1-Math.pow(1-SMOOTH,dt));if(Math.abs(tp-S.sp)<2e-4)S.sp=tp;if(S.car&&S.I<1)S.I=Math.min(1,S.I+INTRO*dt);
 var f=TL(S.sp,S.I);if(!dn){S.uy*=.95;if(Math.abs(S.uy)<1e-4)S.uy=0}
 dust.rotation.y=S.sp*1.5;pv.rotation.y=f.yaw+S.uy;pv.position.set(Math.sin(f.yaw)*f.dist,0,Math.cos(f.yaw)*f.dist);
 hold.rotation.x=-.04*eo(f.s)*(1-f.l*.6);hold.position.y=f.s>0&&f.l<.3?Math.sin(t*.09)*.012*f.s:0;
 cam.position.set(f.l*1.6,f.cy,f.cd*S.k);cam.lookAt(f.l*2.4,f.ly,0);
 ring.scale.setScalar(1+f.e*.75);ring.material.opacity=1-f.e*.4;sh.material.opacity=1-f.e*.75;
 if(f.stage!==S.stg){S.stg=f.stage;var g=$('#stg');if(g){$('#sgn').textContent='0'+(f.stage+1);$('#sgt').textContent=STG[f.stage][0];$('#sgd').textContent=STG[f.stage][1];g.classList.remove('sw');void g.offsetWidth;g.classList.add('sw')}rail.forEach(function(i,k){i.classList.toggle('on',k===f.stage)})}
 var p=S.sp,v=p>.72?Math.round(330*Math.pow(f.l,.8)):Math.round(140*(1-eo(f.a)));if(kmh){kmh.style.opacity=(S.car&&f.a<.97)||p>.72?1:0;kmh.firstChild.textContent=v}
 if(stk)stk.style.opacity=Math.max(f.l>0?cl(f.l*3):0,f.a>0&&f.a<1?(1-f.a)*.7:0);if(hn&&hn.getAttribute('data-l')==='0')hn.style.opacity=cl(1-p*25);
 if(b.bottom<0||b.top>innerHeight)return;
 var k=[S.sp.toFixed(4),S.I.toFixed(3),S.uy.toFixed(4),S.car?1:0,S.k].join();if(k===LK&&!(f.s>0&&f.l<.3)&&!S.force)return;LK=k;S.force=0;
 if(S.car)S.car.set(f.e,(11*eo(f.a)+30*Math.pow(f.l,2.2))/S.car.R+60*f.s*f.s);
 r.render(sc,cam)}
lmRun=true;lp();
var STP=[0,.1,.32,.62,.9];
document.addEventListener('click',function(e){var ri=e.target.closest('#rail i'),cu=e.target.closest('.cue');if(!ri&&!cu)return;var i=ri?rail.indexOf(ri):1,top=pin.getBoundingClientRect().top+pageYOffset;scrollTo({top:top+STP[i]*(pin.offsetHeight-innerHeight)+2,behavior:'smooth'})});
})();
