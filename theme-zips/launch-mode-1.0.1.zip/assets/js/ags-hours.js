/* ags-hours.js - shows opening hours grouped by identical days,
   e.g. "Monday – Saturday: 9 AM – 6 PM" + "Sunday: Closed".
   Reads the raw dealer hours from <template id="ags-hours-src">. If the hours
   cannot be understood, the page is left exactly as the platform rendered it. */
(function () {
  "use strict";
  var DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  var DAY_RE = "(mon(?:day)?|tue(?:s(?:day)?)?|wed(?:s|nesday)?|thu(?:r(?:s(?:day)?)?)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)\\.?";
  var RANGE_SEP = "\\s*(?:-|–|—|to|thru|through)\\s*";
  var LIST_SEP = "\\s*(?:&|and|\\/|\\+|,)\\s*";
  var DAYSPEC = new RegExp("\\b" + DAY_RE + "(?:(?:" + RANGE_SEP + "|" + LIST_SEP + ")" + DAY_RE + ")*", "i");
  var DAY_ONE = new RegExp("^" + DAY_RE + "$", "i");
  var TIME = "(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?|a|p)?";
  var TIME_RANGE = new RegExp(TIME + "\\s*(?:-|–|—|to|until|till)\\s*" + TIME, "i");

  function dayIndex(tok) {
    var t = tok.toLowerCase().replace(/\./g, "").slice(0, 3);
    return ["mon", "tue", "wed", "thu", "fri", "sat", "sun"].indexOf(t);
  }
  function expandDays(spec) {
    var out = [], parts = spec.split(new RegExp(LIST_SEP, "i"));
    parts.forEach(function (p) {
      var r = p.split(new RegExp(RANGE_SEP, "i")).filter(Boolean);
      if (r.length === 2 && DAY_ONE.test(r[0].trim()) && DAY_ONE.test(r[1].trim())) {
        var a = dayIndex(r[0].trim()), b = dayIndex(r[1].trim());
        if (a < 0 || b < 0) return;
        for (var i = a; ; i = (i + 1) % 7) { if (out.indexOf(i) < 0) out.push(i); if (i === b) break; }
      } else if (DAY_ONE.test(p.trim())) {
        var d = dayIndex(p.trim()); if (d >= 0 && out.indexOf(d) < 0) out.push(d);
      }
    });
    return out;
  }
  function mer(m) { return m ? (m.charAt(0).toLowerCase() === "a" ? "AM" : "PM") : ""; }
  function fmt(h, m, ap) { return h + (m && m !== "00" ? ":" + m : "") + " " + ap; }
  function parseTimes(s) {
    var m = TIME_RANGE.exec(s); if (!m) return null;
    var h1 = +m[1], m1 = m[2], a1 = mer(m[3]), h2 = +m[4], m2 = m[5], a2 = mer(m[6]);
    if (h1 > 24 || h2 > 24) return null;
    if (h1 > 12) { h1 -= 12; a1 = "PM"; } else if (h1 === 0) { h1 = 12; a1 = "AM"; } else if (h1 === 12 && !a1) a1 = "PM";
    if (h2 > 12) { h2 -= 12; a2 = "PM"; } else if (h2 === 0 || h2 === 24) { h2 = 12; a2 = "AM"; } else if (h2 === 12 && !a2) a2 = "PM";
    if (!a1 && !a2) { a1 = (h1 >= 5 && h1 <= 11) ? "AM" : "PM"; a2 = "PM"; }
    else if (!a1) a1 = (a2 === "PM" && h1 >= 5 && h1 <= 11) ? "AM" : a2;
    else if (!a2) a2 = (a1 === "AM" && h2 > h1 && h2 < 12 && h2 > 8) ? "AM" : "PM";
    return fmt(h1, m1, a1) + " – " + fmt(h2, m2, a2);
  }
  function segments(text) {
    var out = [], dayAfterComma = new RegExp(",\\s*(?=" + DAY_RE + "\\b)", "i");
    text.replace(/<br\s*\/?>/gi, "\n").split(/[\n;|·•]+/).forEach(function (piece) {
      var cur = "";
      piece.split(dayAfterComma).forEach(function (part) {
        /* split on ", <day>" only once the text so far already has its hours */
        if (cur && (/\d|closed|appointment/i.test(cur))) { out.push(cur); cur = part; }
        else cur = cur ? cur + ", " + part : part;
      });
      if (cur) out.push(cur);
    });
    return out;
  }
  function parse(raw) {
    var map = {}, any = false;
    segments(raw).forEach(function (seg) {
      seg = seg.trim(); if (!seg) return;
      var dm = DAYSPEC.exec(seg); if (!dm) return;
      var days = expandDays(dm[0]); if (!days.length) return;
      var rest = seg.slice(0, dm.index) + " " + seg.slice(dm.index + dm[0].length);
      var val;
      if (/closed|by\s+appointment\s+only/i.test(rest) && !TIME_RANGE.test(rest)) val = /closed/i.test(rest) ? "Closed" : "By appointment";
      else val = parseTimes(rest);
      if (!val) return;
      days.forEach(function (d) { map[d] = val; }); any = true;
    });
    if (!any) return null;
    for (var i = 0; i < 7; i++) if (!map[i]) map[i] = "Closed";
    var groups = [], start = 0;
    for (var j = 1; j <= 7; j++) {
      if (j === 7 || map[j] !== map[start]) {
        var label = start === j - 1 ? DAYS[start] : DAYS[start] + " – " + DAYS[j - 1];
        groups.push(label + ": " + map[start]); start = j;
      }
    }
    return groups;
  }

  var src = document.getElementById("ags-hours-src"); if (!src) return;
  var holder = src.content || src;
  function val(sel) { var n = holder.querySelector(sel); return n ? n.textContent.replace(/\s+/g, " ").trim() : ""; }
  var W = val("[data-w]"), WE = val("[data-we]"), SH = val("[data-s]");
  var lines = parse(W + "\n" + WE);
  if (!lines && SH) lines = parse(SH);
  if (!lines) return;
  var FULL = lines.join(" · ");
  var HEAD = lines.length > 1 ? lines.slice(0, -1).join(" · ") : lines[0];
  var TAIL = lines.length > 1 ? lines[lines.length - 1] : "";

  function norm(s) { return (s || "").replace(/\s+/g, " ").trim(); }
  function nextPartner(node) {
    var n = node.nextSibling;
    while (n) {
      if (n.nodeType === 3 && !norm(n.data)) { n = n.nextSibling; continue; }
      if (n.nodeType === 1 && (n.tagName === "BR" || /^[|·•]$/.test(norm(n.textContent)))) { n = n.nextSibling; continue; }
      return n;
    }
    return null;
  }
  function setText(n, t) { if (n.nodeType === 3) { if (n.data !== t) n.data = t; } else if (n.textContent !== t) n.textContent = t; }
  function hideGapBefore(n, stopAt) {
    var p = n.previousSibling;
    while (p && p !== stopAt) { var q = p.previousSibling; if (p.nodeType === 1 && (p.tagName === "BR" || /^[|·•]$/.test(norm(p.textContent)))) p.style.display = "none"; p = q; }
  }
  function leafOf(n) { return n.nodeType === 1 && n.children.length === 0 ? n : null; }

  function run(root) {
    if (!root || !root.querySelectorAll) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), list = [], t;
    while ((t = walker.nextNode())) list.push(t);
    list.forEach(function (tn) {
      if (!tn.parentNode || tn.parentNode.closest && tn.parentNode.closest("script,style,template,textarea")) return;
      var s = norm(tn.data); if (!s) return;
      var unit = (tn.parentNode.childNodes.length === 1 && leafOf(tn.parentNode)) ? tn.parentNode : tn;
      if (W && s === W) {
        var partner = nextPartner(unit), pn = partner && (partner.nodeType === 3 ? partner : leafOf(partner));
        if (pn && WE && norm(pn.textContent) === WE) {
          setText(unit, HEAD);
          if (TAIL) setText(pn, TAIL); else { pn.nodeType === 1 ? (pn.style.display = "none") : setText(pn, ""); hideGapBefore(partner, unit); }
        } else setText(unit, FULL);
        return;
      }
      if (SH && s === SH) { setText(unit, FULL); return; }
      if (W && WE && s === WE) return; /* handled with its pair, or left as is */
      if (W && s.indexOf(W) >= 0) {
        var out = s;
        if (WE && out.indexOf(WE) >= 0) out = out.split(WE).join("").replace(/\s*([.,|·])\s*\1/g, "$1").replace(/\s{2,}/g, " ").replace(/\s+([.,])/g, "$1");
        out = out.split(W).join(FULL);
        if (out !== s) tn.data = out;
      }
    });
  }
  function start() {
    run(document.body);
    if (window.MutationObserver) {
      var timer = 0;
      new MutationObserver(function () { clearTimeout(timer); timer = setTimeout(function () { run(document.body); }, 60); })
        .observe(document.body, { childList: true, subtree: true });
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
  window.agsFormatHours = parse;
})();
