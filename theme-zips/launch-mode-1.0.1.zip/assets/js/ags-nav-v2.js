/* Header navigation (all themes) — v2
   1. Dropdowns ("Our Store", "Financing"): desktop = menu under the item, phone/vertical menus = tap to expand.
   2. Pages the platform adds to the menu (e.g. "Cars ▾ Sedan") are turned into the same dropdowns.
   3. When the menu runs out of room, the text shrinks step by step instead of breaking the layout. */
(function () {
  "use strict";
  var SKIP = /(^|\s)[\w-]*(meta|addr|call|extra|soc|cta|more)[\w-]*(\s|$)/i;
  var CHEV = '<svg class="ags-dd-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  var MIN_SCALE = 0.62;
  function all(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function hoverDevice() { return window.matchMedia && matchMedia("(hover:hover) and (pointer:fine)").matches; }

  /* ---------- dropdowns ---------- */
  function stacked(dd) {
    var p = dd.parentElement; if (!p) return false;
    var cs = getComputedStyle(p);
    if (cs.display === "none") return true;
    if (cs.display.indexOf("flex") < 0) return true;
    return cs.flexDirection.indexOf("column") === 0 || cs.position === "absolute" || cs.position === "fixed";
  }
  function setOpen(dd, open) { dd.classList.toggle("is-open", open); var b = dd.querySelector(".ags-dd-btn"); if (b) b.setAttribute("aria-expanded", String(open)); }
  function closeDesktop(except) { all("[data-ags-dd]").forEach(function (d) { if (d !== except && !d.classList.contains("ags-dd--stack")) setOpen(d, false); }); }
  function layout() { all("[data-ags-dd]").forEach(function (d) { var s = stacked(d); if (s !== d.classList.contains("ags-dd--stack")) { d.classList.toggle("ags-dd--stack", s); setOpen(d, false); } }); }
  function bind(d) {
    var b = d.querySelector(".ags-dd-btn"); if (!b || d.__ags) return; d.__ags = true;
    function toggle(e) {
      layout();
      /* a dropdown whose title is itself a page: on a desktop mouse, a click opens that page */
      if (b.getAttribute("href") && !d.classList.contains("ags-dd--stack") && hoverDevice() && e.type === "click") return;
      e.preventDefault(); e.stopPropagation();
      var open = !d.classList.contains("is-open");
      if (!d.classList.contains("ags-dd--stack")) closeDesktop(d);
      setOpen(d, open);
    }
    /* capture on the wrapper, so theme scripts that close the phone menu on every link click never see it */
    d.addEventListener("click", function (e) { var t = e.target.closest && e.target.closest(".ags-dd-btn"); if (t === b) toggle(e); }, true);
    b.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); var open = !d.classList.contains("is-open"); if (!d.classList.contains("ags-dd--stack")) closeDesktop(d); setOpen(d, open); } });
  }

  /* ---------- items added by the platform ---------- */
  function convert(el, list) {
    if (el.hasAttribute("data-ags-dd") || el.matches("a,button") || SKIP.test(el.className || "")) return;
    var links = all("a[href]", el); if (links.length < 2) return;
    var trig = el.querySelector("a,button,summary,span") || links[0];
    var label = (trig.textContent || "").replace(/[▾▼⌄⌃▴▲˅˄›»]/g, "").replace(/\s+/g, " ").trim();
    if (!label) return;
    var href = trig.tagName === "A" ? trig.getAttribute("href") : null; if (href === "#" || href === "") href = null;
    var subs = links.filter(function (a) { return a !== trig; });
    var wrap = document.createElement(list ? "li" : "div"); wrap.className = "ags-dd ags-dd--added"; wrap.setAttribute("data-ags-dd", "");
    var btn = document.createElement("a"); btn.className = "ags-dd-btn"; btn.setAttribute("role", "button"); btn.setAttribute("tabindex", "0"); btn.setAttribute("aria-expanded", "false"); btn.setAttribute("aria-haspopup", "true");
    if (href) btn.setAttribute("href", href);
    btn.textContent = label; btn.insertAdjacentHTML("beforeend", CHEV);
    var menu = document.createElement("div"); menu.className = "ags-dd-menu";
    if (href) { var self = document.createElement("a"); self.href = href; self.textContent = label; self.className = "ags-dd-self"; menu.appendChild(self); }
    subs.forEach(function (a) { var n = document.createElement("a"); n.href = a.getAttribute("href"); n.textContent = (a.textContent || "").trim(); if (a.target) n.target = a.target; if (a.rel) n.rel = a.rel; menu.appendChild(n); });
    wrap.appendChild(btn); wrap.appendChild(menu);
    el.parentNode.replaceChild(wrap, el);
  }
  function normalize(c) { var list = c.tagName === "UL" || c.tagName === "OL"; Array.prototype.slice.call(c.children).forEach(function (ch) { convert(ch, list); }); }

  /* ---------- shrink-to-fit ---------- */
  function label(ch) {
    if (ch.matches("a,button")) return ch;
    return ch.querySelector(":scope > .ags-dd-btn, :scope > a, :scope > button, :scope > span > a, a");
  }
  function fit(nav) {
    var hostRow = nav.closest("header, nav, .site-head, .navbar") || nav.parentElement || nav;
    hostRow.classList.add("ags-fitting");
    try { fitInner(nav); } finally { void nav.offsetWidth; hostRow.classList.remove("ags-fitting"); }
  }
  function fitInner(nav) {
    var kids = Array.prototype.slice.call(nav.children).filter(function (k) { return k.offsetWidth > 0 && !SKIP.test(k.className || ""); });
    var labels = kids.map(label).filter(Boolean);
    labels.forEach(function (l) { l.style.removeProperty("font-size"); });
    nav.style.removeProperty("column-gap"); nav.classList.remove("ags-nav-tight");
    var cs = getComputedStyle(nav);
    if (!nav.offsetWidth || cs.display.indexOf("flex") < 0 || cs.flexDirection.indexOf("column") === 0 || cs.position === "absolute" || cs.position === "fixed") return;
    /* the space the menu can have = header row width minus the logo, the phone button and the gaps
       (measured at their natural size, so the result does not change as the menu text shrinks) */
    var item = nav; while (item.parentElement && getComputedStyle(item.parentElement).display.indexOf("flex") < 0) item = item.parentElement;
    var row = item.parentElement; if (!row) return;
    var rcs = getComputedStyle(row), sibs = Array.prototype.slice.call(row.children).filter(function (x) {
      if (x === item || !x.offsetWidth) return false; var p = getComputedStyle(x).position; return p !== "absolute" && p !== "fixed"; });
    var saved = sibs.map(function (x) { return x.style.getPropertyValue("flex") + "|" + x.style.getPropertyPriority("flex"); });
    sibs.forEach(function (x) { x.style.setProperty("flex", "0 0 auto", "important"); });
    var used = sibs.reduce(function (t, x) { var m = getComputedStyle(x); return t + x.getBoundingClientRect().width + (parseFloat(m.marginLeft) || 0) + (parseFloat(m.marginRight) || 0); }, 0);
    sibs.forEach(function (x, i) { var sv = saved[i].split("|"); if (sv[0]) x.style.setProperty("flex", sv[0], sv[1]); else x.style.removeProperty("flex"); });
    var icsI = getComputedStyle(item);
    var room = row.clientWidth - (parseFloat(rcs.paddingLeft) || 0) - (parseFloat(rcs.paddingRight) || 0) - used
      - (parseFloat(rcs.columnGap) || 0) * sibs.length - (parseFloat(icsI.marginLeft) || 0) - (parseFloat(icsI.marginRight) || 0)
      - (item !== nav ? 0 : 0) - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
    function over() {
      if (!kids.length) return false;
      var a = kids[0].getBoundingClientRect(), z = kids[kids.length - 1].getBoundingClientRect();
      return (z.right - a.left) > room + 1;
    }
    if (!over()) return;
    var base = labels.map(function (l) { return parseFloat(getComputedStyle(l).fontSize) || 15; });
    var gap = parseFloat(cs.columnGap) || 0, s = 1;
    while (over() && s > MIN_SCALE) {
      s = Math.max(MIN_SCALE, Math.round((s - 0.04) * 100) / 100);
      labels.forEach(function (l, i) { l.style.setProperty("font-size", (base[i] * s).toFixed(2) + "px", "important"); });
      nav.style.setProperty("column-gap", (gap * Math.max(s - 0.1, 0.5)).toFixed(1) + "px", "important");
    }
    if (over()) nav.classList.add("ags-nav-tight");
  }

  /* ---------- run ---------- */
  function refresh() {
    all("[data-ags-nav],[data-ags-mnav]").forEach(normalize);
    all("[data-ags-dd]").forEach(bind);
    layout();
    all("[data-ags-nav]").forEach(fit);
  }
  function init() {
    refresh();
    document.addEventListener("click", function (e) { if (!e.target.closest || !e.target.closest("[data-ags-dd]")) closeDesktop(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeDesktop(); });
    /* throttle (not debounce): pages that fire resize events non-stop must not starve the re-check */
    var t = null; function later(ms) { if (t) return; t = setTimeout(function () { t = null; refresh(); }, ms || 100); }
    addEventListener("resize", function () { later(100); });
    addEventListener("load", function () { later(10); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { later(10); });
    setTimeout(refresh, 600); setTimeout(refresh, 1800); setTimeout(refresh, 4000);
    /* the platform may add menu items after the page loads */
    /* watch the whole page: some themes rebuild their header after load, and the platform can add items at any time */
    if (window.MutationObserver) {
      var SEL = "[data-ags-nav],[data-ags-mnav]";
      new MutationObserver(function (recs) {
        for (var i = 0; i < recs.length; i++) {
          var r = recs[i], tg = r.target;
          if (tg.nodeType === 1 && (tg.matches(SEL) || tg.closest(SEL))) { later(30); return; }
          for (var j = 0; j < r.addedNodes.length; j++) { var n = r.addedNodes[j]; if (n.nodeType === 1 && (n.matches(SEL) || n.querySelector(SEL))) { later(30); return; } }
        }
      }).observe(document.body, { childList: true, subtree: true });
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
