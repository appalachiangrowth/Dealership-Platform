/* pa-drawer.js v2 — mobile side menu (all themes).
   Opens from [data-pa-drawer-open] (or the theme's own button named in data-trigger).
   Each time it opens, the menu is rebuilt from the desktop header menu (data-src), so custom pages,
   dropdowns ("Our Store", "Financing") and feature switches always match:
     - plain links  -> one row with an icon
     - dropdowns    -> a group that expands in place (the group holding the current page starts open)
   Financing / Trade-In shortcuts show only when those features are switched on (window.FT_CFG).
   Light on phones: one panel + plain overlay, no blur, nothing runs while it is closed. */
(function () {
  "use strict";
  var d = document.getElementById("paDrawer"); if (!d) return;
  var panel = d.querySelector(".pa-drawer-panel"), nav = d.querySelector(".pd-nav") || d.querySelector(".pa-drawer-nav");
  var trig = d.getAttribute("data-trigger") || "", srcs = (d.getAttribute("data-src") || "header nav").split("|");
  var RM = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var opener = null, closeT = 0;
  var SKIP_HREF = /^(tel:|mailto:|sms:|javascript:)|facebook\.com|instagram\.com|google\.[a-z.]+\/(maps|search)|maps\.google|maps\.app\.goo/i;
  var SKIP_CLS = /(^|\s)[\w-]*(meta|addr|call|extra|soc|social|cta|phone|search|fav|btn)[\w-]*(\s|$)/i;

  var SV = function (p) { return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + "</svg>"; };
  var ICONS = {
    home: SV('<path d="M3 11 12 4l9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>'),
    car: SV('<path d="M5 17h14M3 13l2-5a2 2 0 0 1 2-1.3h10A2 2 0 0 1 19 8l2 5v4a1 1 0 0 1-1 1h-1M4 18H3v-5"/><circle cx="7.5" cy="17" r="1.8"/><circle cx="16.5" cy="17" r="1.8"/><path d="M3 13h18"/>'),
    truck: SV('<path d="M2 16V7h11v9M13 10h4l4 4v2h-2"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="16.5" cy="17" r="1.8"/><path d="M8.5 17h6"/>'),
    store: SV('<path d="M4 9 5.5 4h13L20 9"/><path d="M4 9a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0"/><path d="M5 11v9h14v-9M10 20v-5h4v5"/>'),
    info: SV('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'),
    blog: SV('<path d="M5 4h10l4 4v12H5z"/><path d="M14 4v5h5M8 13h8M8 17h6"/>'),
    money: SV('<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/>'),
    trade: SV('<path d="M4 8h13l-3-3M20 16H7l3 3"/>'),
    mail: SV('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
    star: SV('<path d="m12 3 2.7 5.6 6.1.8-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1-4.4-4.3 6.1-.8z"/>'),
    page: SV('<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/>'),
    dot: SV('<circle cx="12" cy="12" r="3"/>')
  };
  var CHEV = '<svg class="pd-chev" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  var ARR = '<svg class="pd-arr" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  var EXT = '<svg class="pd-arr" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function text(el) { if (!el) return ""; var c = el.cloneNode(true); [].slice.call(c.querySelectorAll("svg,.sr-no,[aria-hidden='true']")).forEach(function (x) { x.remove(); }); var t = (c.textContent || "").replace(/[▾▼⌄›»↗→]/g, "").replace(/\s+/g, " ").trim(); return t || (el.getAttribute && el.getAttribute("aria-label")) || ""; }
  function iconFor(label, href) {
    var s = (label + " " + (href || "")).toLowerCase();
    if (/financ|credit|loan|lender|pre-?approv/.test(s)) return ICONS.money;
    if (/trade/.test(s)) return ICONS.trade;
    if (/truck/.test(s)) return ICONS.truck;
    if (/inventor|vehicle|cars|sedan|suv|wagon|used|stock|showroom/.test(s)) return ICONS.car;
    if (/store|dealer|shop/.test(s)) return ICONS.store;
    if (/about|story|team|why/.test(s)) return ICONS.info;
    if (/blog|news|article/.test(s)) return ICONS.blog;
    if (/contact|visit|location/.test(s)) return ICONS.mail;
    if (/review|testimon/.test(s)) return ICONS.star;
    if (/^home\b|#\/?$|index\.html|#home|#hero/.test(s)) return ICONS.home;
    return ICONS.page;
  }
  function here(a) {
    try {
      var L = location; if (a.href === L.href) return true;
      var path = L.pathname.replace(/\/index\.html$/, "/"), up = a.pathname.replace(/\/index\.html$/, "/");
      if (up !== path) return false;
      var h = a.hash || "";
      if (/^#(home|hero|top)$/.test(h) && (!L.hash || L.hash === "#" || L.hash === h)) return true;
      if (h.length > 1 && h !== "#/") return L.hash === h || (L.hash.indexOf(h + "/") === 0) || (L.hash.indexOf(h + "?") === 0);
      return !L.hash || L.hash === "#" || L.hash === "#/" || L.hash === "#home";
    } catch (e) { return false; }
  }
  function usable(a) { var h = a.getAttribute("href"); return h !== null && !SKIP_HREF.test(h) && text(a); }

  /* read the header menu into [{type:"link",a}, {type:"group",label,links:[a]}] */
  function collect(box, out) {
    var kids = [].slice.call(box.children);
    kids.forEach(function (ch) {
      if (ch.closest(".pa-drawer")) return;
      if (ch.classList.contains("ft-more")) { var m = ch.querySelector(".ft-more-menu"); if (m) collect(m, out); return; }
      if (SKIP_CLS.test(ch.className && ch.className.baseVal === undefined ? ch.className : "") && !ch.hasAttribute("data-ags-dd")) return;
      var dd = ch.hasAttribute("data-ags-dd") ? ch : ch.querySelector(":scope > [data-ags-dd]");
      if (dd) {
        var links = [].slice.call(dd.querySelectorAll(".ags-dd-menu a[href]")).filter(usable);
        if (links.length) out.push({ type: "group", label: text(dd.querySelector(".ags-dd-btn")), links: links, fin: dd.hasAttribute("data-ft-fin-nav") || !!dd.querySelector("[data-ft-lender]") });
        return;
      }
      var all = ch.matches("a[href]") ? [ch] : [].slice.call(ch.querySelectorAll("a[href]"));
      all = all.filter(usable);
      if (!all.length) return;
      if (all.length === 1) { out.push({ type: "link", a: all[0] }); return; }
      var head = ch.querySelector(":scope > a, :scope > span, :scope > button, :scope > summary");
      out.push({ type: "group", label: text(head) || text(all[0]), links: all.filter(function (a) { return a !== head || a.getAttribute("href") !== "#"; }) });
    });
    return out;
  }
  function linkAttrs(a) {
    var h = a.getAttribute("href"), ext = a.target === "_blank" || (/^https?:/i.test(h) && h.indexOf(location.origin) !== 0);
    return ' href="' + esc(h) + '"' + (ext ? ' target="_blank" rel="noopener"' : "") + (a.hasAttribute("data-ft-lender") ? " data-ft-lender" : "");
  }
  function build() {
    var items = [];
    for (var i = 0; i < srcs.length; i++) {
      var box = document.querySelector(srcs[i]); if (!box) continue;
      items = collect(box, []); if (items.length >= 2) break;
    }
    if (!items.length) return;
    var seen = {}, cur = false, html = [], n = 0;
    items.forEach(function (it) {
      if (it.type === "link") {
        var t = text(it.a), k = it.a.getAttribute("href") + "|" + t.toLowerCase(); if (seen[k]) return; seen[k] = 1;
        var on = !cur && here(it.a); if (on) cur = true;
        var ext = it.a.target === "_blank";
        html.push('<a class="pd-link"' + linkAttrs(it.a) + (on ? ' aria-current="page"' : "") + ' style="--i:' + (n++) + '"><i class="pd-ico">' + iconFor(t, it.a.getAttribute("href")) + "</i><span>" + esc(t) + "</span>" + (ext ? EXT : ARR) + "</a>");
      } else {
        var subs = [], open = false;
        it.links.forEach(function (a) {
          var t = text(a), k = a.getAttribute("href") + "|" + t.toLowerCase(); if (seen[k] && a.getAttribute("href") !== "#") return; seen[k] = 1;
          var on = !cur && a.getAttribute("href") !== "#" && here(a); if (on) { cur = true; open = true; }
          subs.push('<a class="pd-sub"' + linkAttrs(a) + (on ? ' aria-current="page"' : "") + "><span>" + esc(t) + "</span>" + (a.target === "_blank" || /^https?:/i.test(a.getAttribute("href")) ? EXT : "") + "</a>");
        });
        if (!subs.length) return;
        var id = "pdg" + (n);
        html.push('<div class="pd-grp' + (open ? " is-open" : "") + '"' + (it.fin ? " data-ft-fin-nav" : "") + ' style="--i:' + (n++) + '"><button type="button" class="pd-grp-btn" aria-expanded="' + open + '" aria-controls="' + id + '"><i class="pd-ico">' + iconFor(it.label, "") + "</i><span>" + esc(it.label) + "</span>" + CHEV + '</button><div class="pd-grp-list" id="' + id + '"' + (open ? "" : " hidden") + ">" + subs.join("") + "</div></div>");
      }
    });
    nav.innerHTML = html.join("");
    /* Financing / Trade-In shortcuts follow the dealer settings */
    var C = window.FT_CFG, fin = d.querySelector("[data-pd-fin]"), tr = d.querySelector("[data-pd-trade]"), box2 = d.querySelector("[data-pd-ft]");
    if (fin) fin.hidden = !(C && C.fin && C.fin.on && window.FT);
    if (tr) tr.hidden = !(C && C.trade && C.trade.on && window.FT);
    if (box2) box2.hidden = (!fin || fin.hidden) && (!tr || tr.hidden);
  }
  function toggleGroup(g, open) {
    var b = g.querySelector(".pd-grp-btn"), l = g.querySelector(".pd-grp-list");
    if (open === undefined) open = !g.classList.contains("is-open");
    g.classList.toggle("is-open", open); b.setAttribute("aria-expanded", String(open)); l.hidden = !open;
  }
  function focusables() { return [].slice.call(panel.querySelectorAll('a[href],button:not([disabled])')).filter(function (el) { return el.offsetParent !== null; }); }
  function open(from) {
    clearTimeout(closeT); build(); opener = from || document.activeElement;
    d.hidden = false; document.documentElement.classList.add("pa-drawer-lock");
    panel.style.transform = ""; panel.scrollTop = 0; var body = d.querySelector(".pd-body"); if (body) body.scrollTop = 0;
    if (opener && opener.setAttribute) opener.setAttribute("aria-expanded", "true");
    requestAnimationFrame(function () { requestAnimationFrame(function () { d.classList.add("is-open"); var f = d.querySelector(".pd-x") || panel; try { f.focus({ preventScroll: true }); } catch (e) {} }); });
  }
  function close(keepFocus) {
    if (d.hidden) return;
    d.classList.remove("is-open"); document.documentElement.classList.remove("pa-drawer-lock"); panel.style.transform = "";
    if (opener && opener.setAttribute) { opener.setAttribute("aria-expanded", "false"); if (!keepFocus) { try { opener.focus({ preventScroll: true }); } catch (e) {} } }
    closeT = setTimeout(function () { d.hidden = true; }, RM ? 0 : 360);
  }
  window.PA_DRAWER = { open: open, close: close };

  /* capture phase: the theme's own menu button opens this drawer instead of its old mobile menu */
  window.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest((trig ? trig + "," : "") + "[data-pa-drawer-open]");
    if (t && !d.contains(t)) { e.preventDefault(); e.stopImmediatePropagation(); if (d.hidden) open(t); else close(); return; }
    if (d.hidden || !d.contains(e.target)) return;
    var g = e.target.closest(".pd-grp-btn");
    if (g) { e.preventDefault(); var grp = g.parentNode; toggleGroup(grp); if (grp.classList.contains("is-open")) setTimeout(function () { try { grp.scrollIntoView({ block: "nearest", behavior: RM ? "auto" : "smooth" }); } catch (x) {} }, 60); return; }
    if (e.target.closest("[data-pa-close]")) { e.preventDefault(); close(); return; }
    if (e.target.closest("[data-ft-open]")) { close(true); return; }   /* the Financing / Trade-In form opens on top */
    var a = e.target.closest("a[href]"); if (!a) return;
    var h = a.getAttribute("href") || "";
    if (a.hasAttribute("data-ft-lender") && (h === "#" || h === "") && window.FT) { e.preventDefault(); close(true); window.FT.open("financing"); return; }
    close(true);
  }, true);
  document.addEventListener("keydown", function (e) {
    if (d.hidden) return;
    if (e.key === "Escape") { e.preventDefault(); close(); return; }
    if (e.key !== "Tab") return;
    var f = focusables(); if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  /* swipe the panel to the right to close it */
  var sx = null, sy = null, dx = 0, drag = false;
  panel.addEventListener("touchstart", function (e) { if (e.touches.length !== 1) return; sx = e.touches[0].clientX; sy = e.touches[0].clientY; dx = 0; drag = false; }, { passive: true });
  panel.addEventListener("touchmove", function (e) {
    if (sx === null) return;
    var x = e.touches[0].clientX - sx, y = e.touches[0].clientY - sy;
    if (!drag && Math.abs(x) > 12 && Math.abs(x) > Math.abs(y) * 1.3) { drag = true; panel.classList.add("is-drag"); }
    if (drag) { dx = Math.max(0, x); panel.style.transform = "translateX(" + dx + "px)"; }
  }, { passive: true });
  panel.addEventListener("touchend", function () {
    if (drag) { panel.classList.remove("is-drag"); if (dx > Math.min(110, panel.offsetWidth * 0.3)) close(); else panel.style.transform = ""; }
    sx = null; drag = false;
  });
  addEventListener("hashchange", function () { close(true); });
  addEventListener("resize", function () { if (!d.hidden && innerWidth > 1024) close(true); });
})();
