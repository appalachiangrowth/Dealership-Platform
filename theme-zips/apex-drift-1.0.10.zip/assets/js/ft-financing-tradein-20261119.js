/* Financing & Trade-In · shared theme component (AGS dealer platform)
   ----------------------------------------------------------------------------
   One reusable component for every dealership on the platform:
     - Financing inquiry form (modal from vehicle pages, inline on financing.html)
     - Trade-In inquiry form, 3 steps (modal from the homepage section and from
       vehicle pages; vehicle pages attach the vehicle being viewed)
     - "Call about …" links that open the phone dialer

   Settings: window.FT_CFG is resolved by the small inline script that sits right
   after <body> in every template (dealer content fields, or window.SITE.financing
   / window.SITE.tradeIn once the platform provides them).

   Triggers (no JS needed in templates):
     <button data-ft-open="financing">            financing form
     <button data-ft-open="trade">                trade-in form
     add data-ft-vehicle to attach window.FT_VEHICLE (set by the vehicle page)
     <a data-ft-call="fin|trade">                 href filled with the right tel:
     <div data-ft-fin-inline></div>               inline financing form

   Leads post to the existing endpoint api/lead.php (same JSON as the other
   forms) with extra structured fields: leadType, source, vehicle, tradeIn.
   ---------------------------------------------------------------------------- */
(function () {
  "use strict";
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); };
  var str = function (v) { return v == null ? "" : String(v).trim(); };
  var SITE = window.SITE || {};
  var LEAD_URL = "api/lead.php";
  var MAX_PHOTOS = 10, MAX_EDGE = 1600, JPEG_Q = 0.82, MAX_RAW = 25 * 1024 * 1024, MIN_FILL_MS = 2500;
  var BTN_ICO = '<span class="ft-btn-i" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M9 7h8v8"/></svg></span>';
  var PHONE_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>';
  var CHECK_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

  /* ---------- settings ---------- */
  function resolveCfg() {
    if (window.FT_CFG) return window.FT_CFG;
    var c = document.getElementById("ftCfg"), d = c ? c.dataset : {}, F = SITE.financing || {}, T = SITE.tradeIn || SITE.trade_in || {};
    var b = function (p, pk, dk) { var v = p[pk]; if (v === undefined || v === null || v === "") v = d[dk]; if (typeof v === "boolean") return v; return !/^(off|no|false|0|hide|hidden|disable|disabled)$/i.test(str(v)); };
    var ph = function (p, dk) { var v = str(p.phone) || str(d[dk]); if (!v || /^(main|default|site)$/i.test(v)) v = str(SITE.phone || (document.body && document.body.getAttribute("data-phone"))); return v; };
    var fo = b(F, "enabled", "finOn"), to = b(T, "enabled", "tradeOn"), fp = fo && b(F, "showPage", "finPage");
    return (window.FT_CFG = { fin: { on: fo, page: fp, nav: fp && b(F, "showNav", "finNav"), btns: fo && b(F, "showButtons", "finBtns"), phone: ph(F, "finPhone") }, trade: { on: to, home: to && b(T, "showHome", "tradeHome"), btns: to && b(T, "showButtons", "tradeBtns"), phone: ph(T, "tradePhone") } });
  }
  var CFG = resolveCfg();
  function telOf(p) { var d = str(p).replace(/[^0-9+]/g, ""); return d.length >= 7 ? "tel:" + d : ""; }
  /* the dealership's main number keeps the platform's own tel: link (country code etc.) */
  var MAIN_TEL = str(SITE.tel_link) || str(document.body && document.body.getAttribute("data-tel"));
  var digitsOf = function (x) { return str(x).replace(/\D/g, ""); };
  function telFor(p) { if (MAIN_TEL && /^tel:/i.test(MAIN_TEL) && (!str(p) || digitsOf(p) === digitsOf(SITE.phone))) return MAIN_TEL; return telOf(p) || MAIN_TEL; }
  CFG.fin.tel = telFor(CFG.fin.phone);
  CFG.trade.tel = telFor(CFG.trade.phone);

  function fillCallLinks(scope) {
    $$("[data-ft-call]", scope).forEach(function (a) {
      var k = a.getAttribute("data-ft-call") === "trade" ? "trade" : "fin", t = CFG[k].tel;
      if (t) { a.setAttribute("href", t); a.hidden = false; } else a.hidden = true;
    });
    $$("[data-ft-phone]", scope).forEach(function (el) { var k = el.getAttribute("data-ft-phone") === "trade" ? "trade" : "fin"; if (CFG[k].phone) el.textContent = CFG[k].phone; });
  }

  /* ---------- vehicle attached from the vehicle page ---------- */
  function vehicleInfo(v) {
    if (!v || typeof v !== "object") return null;
    var pick = function () { for (var i = 0; i < arguments.length; i++) { var x = str(v[arguments[i]]); if (x) return x; } return ""; };
    var id = pick("id", "slug"), url = location.origin + location.pathname.replace(/[^/]*$/, "") + "vehicle.html" + (id ? "?id=" + encodeURIComponent(id) : "");
    if (/vehicle/i.test(location.pathname)) url = location.href.split("#")[0];
    else if (/vehicle/i.test(location.hash)) url = location.href; /* single-page themes: #/vehicle/... */
    if (/^https?:\/\//i.test(str(v.url))) url = str(v.url);
    var info = { id: id, year: pick("year"), make: pick("make"), model: pick("model"), trim: pick("trim"), stock: pick("stock", "stockNumber", "stock_number"), vin: pick("vin"), price: pick("price"), url: url };
    info.title = [info.year, info.make, info.model, info.trim].filter(Boolean).join(" ") || pick("title") || "Vehicle";
    return info;
  }
  function vehicleCard(vi, label) {
    if (!vi) return "";
    var ids = [vi.stock ? "Stock # " + vi.stock : "", vi.vin ? "VIN " + vi.vin : ""].filter(Boolean).join(" · ");
    return '<div class="ft-veh"><small>' + esc(label) + "</small><b>" + esc(vi.title) + "</b>" + (ids ? "<span>" + esc(ids) + "</span>" : "") + "</div>";
  }

  /* ---------- small form helpers ---------- */
  var uid = 0;
  function field(o) {
    var id = "ftf" + (++uid), req = o.required ? " required" : "", star = o.required ? " *" : "", attrs = o.attrs || "";
    var input;
    if (o.type === "textarea") input = '<textarea class="ft-input" id="' + id + '" name="' + o.name + '"' + req + ' maxlength="' + (o.max || 2000) + '"' + attrs + ">" + esc(o.value || "") + "</textarea>";
    else if (o.type === "select") input = '<select class="ft-input" id="' + id + '" name="' + o.name + '"' + req + attrs + ">" + o.options + "</select>";
    else input = '<input class="ft-input" id="' + id + '" name="' + o.name + '" type="' + (o.type || "text") + '"' + req + ' maxlength="' + (o.max || 160) + '"' + attrs + (o.value ? ' value="' + esc(o.value) + '"' : "") + ">";
    return '<div class="' + (o.full ? "full " : "") + 'ft-fld"><label for="' + id + '">' + esc(o.label) + star + (o.hint ? ' <i>' + esc(o.hint) + "</i>" : "") + "</label>" + input + '<p class="ft-err" aria-live="polite"></p></div>';
  }
  function contactFields() {
    return field({ name: "name", label: "Full name", required: true, max: 120, attrs: ' autocomplete="name"' }) +
      field({ name: "phone", label: "Phone number", required: true, type: "tel", max: 40, attrs: ' autocomplete="tel" inputmode="tel"' }) +
      field({ name: "email", label: "Email address", required: true, type: "email", full: true, max: 160, attrs: ' autocomplete="email"' }) +
      field({ name: "message", label: "Additional message", type: "textarea", full: true, max: 2000, hint: "(optional)" });
  }
  var HONEY = '<div class="ft-honey" aria-hidden="true"><label>Leave this field empty<input name="_honey" tabindex="-1" autocomplete="off"></label></div>';
  function setErr(form, name, msg) {
    var el = form.elements[name]; if (!el) return;
    var box = (el.length && !el.tagName ? el[0] : el).closest(".ft-fld, .ft-cond"), p = box && $(".ft-err", box);
    if (p) p.textContent = msg || "";
    if (el.tagName) el.setAttribute("aria-invalid", msg ? "true" : "false");
    if (box) box.classList.toggle("has-err", !!msg);
  }
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function checkContact(form) {
    var ok = true, v = function (n) { return str(form.elements[n] && form.elements[n].value); };
    var name = v("name"), phone = v("phone"), email = v("email");
    setErr(form, "name", name.length < 2 ? "Please enter your full name." : ""); if (name.length < 2) ok = false;
    var digits = phone.replace(/\D/g, "");
    setErr(form, "phone", digits.length < 7 || digits.length > 15 ? "Please enter a valid phone number." : ""); if (digits.length < 7 || digits.length > 15) ok = false;
    setErr(form, "email", !EMAIL_RE.test(email) ? "Please enter a valid email address." : ""); if (!EMAIL_RE.test(email)) ok = false;
    return ok;
  }
  function focusFirstError(scope) { var b = $(".has-err input, .has-err select, .has-err textarea", scope); if (b) b.focus(); }

  /* ---------- financing form ---------- */
  function financingForm(vi, inline) {
    return '<form class="ft-form" data-ft-form="financing" novalidate>' +
      (inline ? "" : '<p class="ft-kicker">Vehicle financing</p><h2 class="ft-h" id="ftTitle">Apply for <em>financing</em></h2><p class="ft-muted">Share your details and the finance team will contact you about the options available' + (vi ? " for this vehicle" : "") + ".</p>") +
      vehicleCard(vi, "Vehicle you are interested in") +
      '<div class="ft-grid">' + contactFields() + HONEY +
      '<div class="ft-foot"><button class="ft-btn ft-btn--primary" type="submit"><span class="ft-btn-t">Submit financing inquiry</span>' + BTN_ICO + '</button><p class="ft-status" aria-live="polite"></p></div></div>' +
      '<p class="ft-fineprint">No credit check is run by sending this form. The dealership will contact you directly.</p></form>';
  }

  /* ---------- trade-in form (3 steps) ---------- */
  function yearOptions() {
    var y = new Date().getFullYear() + 1, o = '<option value="">Select year</option>';
    for (var i = y; i >= 1981; i--) o += '<option value="' + i + '">' + i + "</option>";
    return o + '<option value="1980 or older">1980 or older</option>';
  }
  var CONDITIONS = [["Excellent", "Like new, no visible wear, no mechanical issues"], ["Good", "Minor wear, well maintained, runs well"], ["Fair", "Noticeable wear or some repairs needed"], ["Poor", "Major damage or mechanical problems"]];
  function tradeForm(vi) {
    var steps = ["Your vehicle", "Condition", "Your details"];
    return '<form class="ft-form ft-trade" data-ft-form="trade" novalidate>' +
      '<p class="ft-kicker">Trade-in request</p><h2 class="ft-h" id="ftTitle">Value my <em>trade-in</em></h2><p class="ft-muted">Tell us about your current vehicle and our team will contact you to discuss your trade-in options.</p>' +
      vehicleCard(vi, "Vehicle you want to purchase") +
      '<ol class="ft-steps" aria-label="Form steps">' + steps.map(function (s, i) { return '<li class="' + (i === 0 ? "is-on" : "") + '"><i>' + (i + 1) + "</i><span>" + s + "</span></li>"; }).join("") + "</ol>" +
      /* step 1 */
      '<fieldset class="ft-step is-on" data-step="1"><legend class="ft-step-t">Step 1 · Current vehicle information</legend><div class="ft-grid">' +
        field({ name: "tv_year", label: "Vehicle year", required: true, type: "select", options: yearOptions() }) +
        field({ name: "tv_make", label: "Vehicle make", required: true, max: 60, attrs: ' autocomplete="off" placeholder="e.g. Toyota"' }) +
        field({ name: "tv_model", label: "Vehicle model", required: true, max: 60, attrs: ' autocomplete="off" placeholder="e.g. Camry"' }) +
        field({ name: "tv_trim", label: "Vehicle trim", max: 60, hint: "(optional)", attrs: ' autocomplete="off" placeholder="e.g. SE"' }) +
        field({ name: "tv_mileage", label: "Current mileage", required: true, max: 9, attrs: ' inputmode="numeric" autocomplete="off" placeholder="e.g. 68,000"' }) +
        field({ name: "tv_vin", label: "VIN", max: 17, hint: "(optional)", attrs: ' autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="17 characters"' }) +
      "</div></fieldset>" +
      /* step 2 */
      '<fieldset class="ft-step" data-step="2" hidden><legend class="ft-step-t">Step 2 · Vehicle condition</legend>' +
        '<div class="ft-cond" role="radiogroup" aria-label="Vehicle condition"><p class="ft-cond-l">Overall condition *</p><div class="ft-cond-grid">' +
        CONDITIONS.map(function (c) { return '<label class="ft-cond-opt"><input type="radio" name="tv_condition" value="' + c[0] + '"><span><b>' + c[0] + "</b><small>" + c[1] + "</small></span></label>"; }).join("") +
        '</div><p class="ft-err" aria-live="polite"></p></div>' +
        '<div class="ft-grid">' +
        field({ name: "tv_issues", label: "Known mechanical issues", type: "textarea", full: true, max: 2000, hint: "(optional)", attrs: ' placeholder="Warning lights, noises, leaks, recent repairs…"' }) +
        field({ name: "tv_info", label: "Additional vehicle information", type: "textarea", full: true, max: 2000, hint: "(optional)", attrs: ' placeholder="Service history, accidents, number of owners, upgrades…"' }) +
        '<div class="full ft-fld ft-photos"><label>Vehicle photos <i>(optional · up to ' + MAX_PHOTOS + ')</i></label>' +
          '<label class="ft-drop"><input type="file" name="tv_photos" accept="image/*" multiple><span class="ft-drop-ico" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></span><span><b>Add photos</b><small>Exterior, interior, odometer and any damage</small></span></label>' +
          '<div class="ft-thumbs" aria-live="polite"></div><p class="ft-err" aria-live="polite"></p></div>' +
        "</div></fieldset>" +
      /* step 3 */
      '<fieldset class="ft-step" data-step="3" hidden><legend class="ft-step-t">Step 3 · Customer information</legend><div class="ft-grid">' + contactFields() + HONEY + "</div></fieldset>" +
      '<div class="ft-step-nav"><button type="button" class="ft-back" data-ft-back hidden>← Back</button><p class="ft-status" aria-live="polite"></p>' +
        '<button type="button" class="ft-btn ft-btn--dark" data-ft-next><span class="ft-btn-t">Continue</span>' + BTN_ICO + "</button>" +
        '<button type="submit" class="ft-btn ft-btn--primary" data-ft-submit hidden><span class="ft-btn-t">Submit Trade-In Request</span>' + BTN_ICO + "</button></div>" +
      '<p class="ft-fineprint">We do not calculate a value online. A member of the team will review your details and contact you.</p></form>';
  }
  function checkTradeStep(form, n) {
    var ok = true, v = function (k) { return str(form.elements[k] && form.elements[k].value); };
    if (n === 1) {
      var req = [["tv_year", "Please select the year."], ["tv_make", "Please enter the make."], ["tv_model", "Please enter the model."]];
      req.forEach(function (r) { var bad = !v(r[0]); setErr(form, r[0], bad ? r[1] : ""); if (bad) ok = false; });
      var mi = v("tv_mileage").replace(/[,\s]/g, "").replace(/mi(les)?$/i, ""), badMi = !/^\d{1,7}$/.test(mi);
      setErr(form, "tv_mileage", badMi ? "Please enter the mileage as a number." : ""); if (badMi) ok = false;
      var vin = v("tv_vin").toUpperCase().replace(/\s/g, ""), badVin = vin && !/^[A-HJ-NPR-Z0-9]{17}$/.test(vin);
      setErr(form, "tv_vin", badVin ? "A VIN has 17 letters and numbers (no I, O or Q)." : ""); if (badVin) ok = false;
    } else if (n === 2) {
      var c = $('input[name="tv_condition"]:checked', form), p = $(".ft-cond .ft-err", form), box = $(".ft-cond", form);
      if (p) p.textContent = c ? "" : "Please choose the condition that fits best."; if (box) box.classList.toggle("has-err", !c); if (!c) ok = false;
    } else if (n === 3) ok = checkContact(form);
    return ok;
  }
  function wireTrade(form) {
    var step = 1, photos = [], busyPhotos = 0;
    var steps = $$(".ft-step", form), dots = $$(".ft-steps li", form), back = $("[data-ft-back]", form), next = $("[data-ft-next]", form), submit = $("[data-ft-submit]", form);
    function go(n) {
      step = n;
      steps.forEach(function (s) { var on = Number(s.getAttribute("data-step")) === n; s.hidden = !on; s.classList.toggle("is-on", on); });
      dots.forEach(function (d, i) { d.classList.toggle("is-on", i + 1 === n); d.classList.toggle("is-done", i + 1 < n); });
      back.hidden = n === 1; next.hidden = n === 3; submit.hidden = n !== 3;
      var st = $(".ft-status", form); if (st) st.textContent = "";
      var scroller = form.closest(".ft-modal-panel"); if (scroller) scroller.scrollTop = 0;
      var first = $(".ft-step.is-on input:not([type=hidden]):not([type=file]), .ft-step.is-on select", form); if (first && window.matchMedia("(hover:hover)").matches) first.focus({ preventScroll: true });
    }
    next.addEventListener("click", function () { if (checkTradeStep(form, step)) go(step + 1); else focusFirstError(form); });
    back.addEventListener("click", function () { go(step - 1); });
    form.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target.tagName === "INPUT" && step < 3) { e.preventDefault(); next.click(); } });
    $$('input[name="tv_condition"]', form).forEach(function (r) { r.addEventListener("change", function () { var b = $(".ft-cond", form); if (b) { b.classList.remove("has-err"); $(".ft-err", b).textContent = ""; } }); });
    var vinIn = form.elements.tv_vin; if (vinIn) vinIn.addEventListener("input", function () { var p = vinIn.selectionStart; vinIn.value = vinIn.value.toUpperCase(); try { vinIn.setSelectionRange(p, p); } catch (_) { } });
    /* photos */
    var input = form.elements.tv_photos, thumbs = $(".ft-thumbs", form), perr = $(".ft-photos .ft-err", form);
    function drawThumbs() {
      thumbs.innerHTML = photos.map(function (p, i) { return '<figure class="ft-thumb"><img src="' + p.dataUrl + '" alt="Photo ' + (i + 1) + '"><button type="button" data-rm="' + i + '" aria-label="Remove photo ' + (i + 1) + '">×</button></figure>'; }).join("") + (busyPhotos ? '<span class="ft-thumb-busy">Preparing ' + busyPhotos + "…</span>" : "");
    }
    thumbs.addEventListener("click", function (e) { var b = e.target.closest("[data-rm]"); if (!b) return; photos.splice(Number(b.getAttribute("data-rm")), 1); drawThumbs(); });
    input.addEventListener("change", function () {
      var files = Array.prototype.slice.call(input.files || []), skipped = 0; input.value = "";
      if (perr) perr.textContent = "";
      files.forEach(function (f) {
        if (photos.length + busyPhotos >= MAX_PHOTOS) { skipped++; return; }
        if (!/^image\//i.test(f.type) || f.size > MAX_RAW) { skipped++; return; }
        busyPhotos++;
        shrink(f).then(function (url) { photos.push({ name: f.name.replace(/\.[^.]+$/, "") + ".jpg", type: "image/jpeg", dataUrl: url }); }, function () { skipped++; })
          .then(function () { busyPhotos--; drawThumbs(); if (skipped && perr) perr.textContent = skipped + " file" + (skipped > 1 ? "s were" : " was") + " skipped (images only, max " + MAX_PHOTOS + " photos)."; });
      });
      drawThumbs();
      if (skipped && perr) perr.textContent = skipped + " file" + (skipped > 1 ? "s were" : " was") + " skipped (images only, max " + MAX_PHOTOS + " photos).";
    });
    form.__photos = function () { return photos; };
    form.__busy = function () { return busyPhotos > 0; };
    form.__step = function () { return step; };
    form.__go = go;
  }
  /* resize + re-encode on the device: smaller upload, strips EXIF/GPS from the photos */
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        try {
          var w = img.naturalWidth, h = img.naturalHeight, s = Math.min(1, MAX_EDGE / Math.max(w, h)), c = document.createElement("canvas");
          c.width = Math.max(1, Math.round(w * s)); c.height = Math.max(1, Math.round(h * s));
          var g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
          URL.revokeObjectURL(url); res(c.toDataURL("image/jpeg", JPEG_Q));
        } catch (e) { URL.revokeObjectURL(url); rej(e); }
      };
      img.onerror = function () { URL.revokeObjectURL(url); rej(new Error("decode")); };
      img.src = url;
    });
  }

  /* ---------- submit (existing lead endpoint) ---------- */
  function line(label, val) { return str(val) ? label + ": " + str(val) + "\n" : ""; }
  function vehLines(vi, head) {
    if (!vi) return "";
    return head + "\n" + line("Vehicle", vi.title) + line("Year", vi.year) + line("Make", vi.make) + line("Model", vi.model) + line("Trim", vi.trim) + line("Stock #", vi.stock) + line("VIN", vi.vin) + line("Listing", vi.url);
  }
  function buildPayload(kind, form, vi, source) {
    var v = function (k) { return str(form.elements[k] && form.elements[k].value); };
    var name = v("name"), phone = v("phone"), email = v("email"), msg = v("message");
    var p = { name: name, email: email, phone: phone, page: location.href, vehicleId: vi ? vi.id : "", _honey: "", leadType: kind === "trade" ? "trade-in" : "financing", source: source, customerMessage: msg, submittedAt: new Date().toISOString() };
    if (vi) p.vehicle = { id: vi.id, year: vi.year, make: vi.make, model: vi.model, trim: vi.trim, stock: vi.stock, vin: vi.vin, url: vi.url };
    var text;
    if (kind === "financing") {
      p.topic = "Financing inquiry" + (vi ? ": " + vi.title : "");
      text = "FINANCING INQUIRY\n" + line("Name", name) + line("Phone", phone) + line("Email", email) + (vi ? "\n" + vehLines(vi, "INTERESTED VEHICLE") : "") + "\n" + line("Message", msg || "(none)");
    } else {
      var photos = form.__photos ? form.__photos() : [], cond = $('input[name="tv_condition"]:checked', form);
      var t = { year: v("tv_year"), make: v("tv_make"), model: v("tv_model"), trim: v("tv_trim"), mileage: v("tv_mileage").replace(/[^\d]/g, ""), vin: v("tv_vin").toUpperCase().replace(/\s/g, ""), condition: cond ? cond.value : "", mechanicalIssues: v("tv_issues"), additionalInfo: v("tv_info"), photos: photos.map(function (x) { return { name: x.name, type: x.type, data: x.dataUrl }; }) };
      p.tradeIn = t;
      var cur = [t.year, t.make, t.model, t.trim].filter(Boolean).join(" ");
      p.topic = "Trade-In request: " + cur + (vi ? " → " + vi.title : "");
      text = "TRADE-IN REQUEST\n" + line("Name", name) + line("Phone", phone) + line("Email", email) +
        "\nCURRENT VEHICLE\n" + line("Vehicle", cur) + line("Year", t.year) + line("Make", t.make) + line("Model", t.model) + line("Trim", t.trim) + line("Mileage", t.mileage ? Number(t.mileage).toLocaleString("en-US") + " mi" : "") + line("VIN", t.vin) +
        line("Condition", t.condition) + line("Known mechanical issues", t.mechanicalIssues) + line("Additional vehicle information", t.additionalInfo) + line("Photos", photos.length ? photos.length + " attached" : "none") +
        (vi ? "\n" + vehLines(vi, "INTERESTED VEHICLE") : "") + "\n" + line("Message", msg || "(none)");
    }
    p.message = text.trim();
    return p;
  }
  function post(payload) {
    return fetch(LEAD_URL, { method: "POST", credentials: "same-origin", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return r.ok && !!j.ok; }); });
  }
  function wireSubmit(form, kind, vi, source, onDone) {
    var opened = Date.now();
    form.addEventListener("input", function (e) { var box = e.target.closest && e.target.closest(".ft-fld.has-err"); if (!box) return; box.classList.remove("has-err"); var er = $(".ft-err", box); if (er) er.textContent = ""; e.target.setAttribute("aria-invalid", "false"); });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (form.__sending) return;
      var st = $(".ft-status", form), btn = $('button[type="submit"]', form);
      if (kind === "trade") {
        for (var n = 1; n <= 3; n++) if (!checkTradeStep(form, n)) { form.__go(n); focusFirstError(form); return; }
        if (form.__busy && form.__busy()) { if (st) st.textContent = "Please wait, your photos are still being prepared…"; return; }
      } else if (!checkContact(form)) { focusFirstError(form); return; }
      var hp = form.elements._honey;
      /* spam: honeypot filled or submitted faster than a person can type -> quietly drop */
      if ((hp && str(hp.value)) || Date.now() - opened < MIN_FILL_MS) { onDone(true); return; }
      var payload = buildPayload(kind, form, vi, source);
      payload._elapsed = Date.now() - opened;
      form.__sending = true; if (btn) { btn.disabled = true; btn.classList.add("is-busy"); }
      if (st) st.textContent = "Sending…";
      var hasPhotos = payload.tradeIn && payload.tradeIn.photos.length;
      post(payload).then(function (ok) {
        if (ok || !hasPhotos) return ok;
        /* the endpoint may refuse a large body: send the details without photos rather than lose the lead */
        var n = payload.tradeIn.photos.length; payload.tradeIn.photos = []; payload.tradeIn.photosNotUploaded = n;
        payload.message = payload.message.replace(/Photos: \d+ attached/, "Photos: " + n + " selected (could not be uploaded - please ask the customer to send them)");
        return post(payload);
      }).then(function (ok) {
        if (ok) onDone(false); else if (st) st.textContent = "Your request could not be sent. Please try again or call the dealership.";
      }).catch(function () { if (st) st.textContent = "Connection issue. Please try again or call the dealership."; })
        .then(function () { form.__sending = false; if (btn) { btn.disabled = false; btn.classList.remove("is-busy"); } });
    });
  }
  function successHtml(kind, inline) {
    var k = kind === "trade" ? "trade" : "fin", tel = CFG[k].tel;
    return '<div class="ft-ok' + (inline ? " is-inline" : "") + '" role="status" tabindex="-1"><span class="ft-ok-ico">' + CHECK_SVG + "</span>" +
      "<h2>" + (kind === "trade" ? "Trade-in request sent" : "Financing inquiry sent") + "</h2>" +
      "<p>Thank you. " + esc(SITE.name || "The dealership") + " has received your " + (kind === "trade" ? "trade-in details" : "inquiry") + " and will contact you shortly.</p>" +
      '<div class="ft-ok-act">' + (tel ? '<a class="ft-btn ft-btn--ghost ft-ok-call" href="' + esc(tel) + '"><span class="ft-btn-t">Call ' + esc(CFG[k].phone || "the dealership") + "</span></a>" : "") +
      (inline ? "" : '<button type="button" class="ft-btn ft-btn--dark" data-ft-close><span class="ft-btn-t">Close</span></button>') + "</div></div>";
  }


  /* ---------- financing companies (vehicle page "Apply for Financing") ----------
     The companies are the entries of the header "Financing" menu: their names and the
     links behind them are edited in the dealer admin (data-ft-lender). "Apply for
     Financing" on a vehicle page lists them; each one goes to its own link. A company
     without a link opens the dealership's financing form with that company noted. */
  function lenderHref(a) {
    var h = str(a.getAttribute("data-ft-href") || a.getAttribute("href"));
    return h && h !== "#" && !/^javascript:/i.test(h) ? h : "";
  }
  function isExternal(h) { return /^https?:\/\//i.test(h) && h.indexOf(location.origin) !== 0; }
  function lenders() {
    var seen = {}, out = [];
    $$("[data-ft-lender]").forEach(function (a) {
      var name = str(a.textContent).replace(/\s+/g, " ");
      if (!name || seen[name.toLowerCase()]) return;
      seen[name.toLowerCase()] = 1;
      var href = lenderHref(a);
      out.push({ name: name, href: href, ext: isExternal(href) });
    });
    return out;
  }
  function enableLenderLinks() {
    $$("[data-ft-lender]").forEach(function (a) {
      if (a.__lenderReady) return; a.__lenderReady = true;
      var h = lenderHref(a);
      if (h) {
        a.setAttribute("href", h); a.removeAttribute("aria-disabled"); a.classList.remove("apx-dd-placeholder");
        if (isExternal(h)) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); }
      } else {
        /* no link set yet: open the dealership financing form instead of jumping to the top */
        a.addEventListener("click", function (e) { e.preventDefault(); openFinFormFor(str(a.textContent)); });
      }
    });
  }
  function monogram(name) {
    var w = str(name).replace(/[^A-Za-z0-9 ]/g, " ").split(/\s+/).filter(Boolean);
    return ((w[0] || "?").charAt(0) + (w.length > 1 ? w[1].charAt(0) : (w[0] || "").charAt(1) || "")).toUpperCase();
  }
  var LENDER_ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  var LENDER_LOCK = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
  function lenderChooser(vi, list) {
    var tel = CFG.fin && CFG.fin.tel;
    return '<div class="ft-lenders"><p class="ft-kicker">Vehicle financing</p><h2 class="ft-h" id="ftTitle">Choose your <em>financing company</em></h2>' +
      '<p class="ft-muted">Select one of our financing partners below to start your application.</p>' +
      vehicleCard(vi, "Financing for") +
      '<p class="ft-lender-label">Our financing partners</p>' +
      '<div class="ft-lender-list" role="list">' + list.map(function (l, i) {
        var meta = l.href ? (l.ext ? "Secure online application · opens in a new tab" : "Online application") : "Apply through our finance team";
        var inner = '<span class="ft-lender-mono" aria-hidden="true">' + esc(monogram(l.name)) + '</span>' +
          '<span class="ft-lender-txt"><b class="ft-lender-n">' + esc(l.name) + '</b><small>' + meta + '</small></span>' +
          '<span class="ft-lender-go">Apply ' + LENDER_ARROW + '</span>';
        return l.href
          ? '<a class="ft-lender" role="listitem" href="' + esc(l.href) + '"' + (l.ext ? ' target="_blank" rel="noopener"' : "") + ' data-ft-lender-pick aria-label="Apply with ' + esc(l.name) + '">' + inner + "</a>"
          : '<button type="button" class="ft-lender" role="listitem" data-ft-lender-form="' + esc(l.name) + '" aria-label="Apply with ' + esc(l.name) + '">' + inner + "</button>";
      }).join("") + "</div>" +
      '<p class="ft-lender-foot">' + LENDER_LOCK + '<span>Your application goes directly to the company you choose.' +
      (tel ? ' Questions? <a href="' + esc(tel) + '">Call our finance team</a>.' : "") + "</span></p></div>";
  }

  /* ---------- modal ---------- */
  var modal, panel, lastFocus;
  function ensureModal() {
    if (modal) return;
    modal = document.createElement("div"); modal.className = "ft-modal"; modal.hidden = true;
    modal.innerHTML = '<div class="ft-modal-bg" data-ft-close></div><div class="ft-modal-panel" role="dialog" aria-modal="true" aria-labelledby="ftTitle"><button type="button" class="ft-modal-x" data-ft-close aria-label="Close">×</button><div class="ft-modal-body"></div></div>';
    document.body.appendChild(modal); panel = $(".ft-modal-panel", modal);
    modal.addEventListener("click", function (e) { if (e.target.closest("[data-ft-close]")) close(); });
    document.addEventListener("keydown", function (e) {
      if (modal.hidden) return;
      if (e.key === "Escape") { e.preventDefault(); close(); }
      if (e.key === "Tab") {
        var f = $$('button:not([disabled]):not([hidden]), a[href], input:not([type=hidden]):not([tabindex="-1"]), select, textarea, [tabindex="0"]', panel).filter(function (x) { return x.offsetParent !== null; });
        if (!f.length) return; var a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      }
    });
  }
  function mountFinForm(body, vi, source, lenderName) {
    body.innerHTML = financingForm(vi, false);
    var form = $("form", body), msg = form && form.elements.message;
    if (msg && str(lenderName)) msg.value = "Financing company: " + str(lenderName);
    wireSubmit(form, "financing", vi, source, function () { body.innerHTML = successHtml("financing", false); var ok = $(".ft-ok", body); if (ok) ok.focus(); });
  }
  function openFinFormFor(name) {
    open("financing", null, "header-financing-menu");
    var body = $(".ft-modal-body"); if (!body) return;
    var form = $("form", body), msg = form && form.elements.message;
    if (msg && str(name)) msg.value = "Financing company: " + str(name);
  }
  function open(kind, vi, source) {
    ensureModal(); lastFocus = document.activeElement;
    var body = $(".ft-modal-body", modal);
    var L = kind === "financing" && vi ? lenders() : [];
    body.innerHTML = kind === "trade" ? tradeForm(vi) : (L.length ? lenderChooser(vi, L) : financingForm(vi, false));
    if (L.length) $$("[data-ft-lender-form]", body).forEach(function (b) { b.addEventListener("click", function () { mountFinForm(body, vi, source, b.getAttribute("data-ft-lender-form")); }); });
    $$("[data-ft-lender-pick]", body).forEach(function (a) { a.addEventListener("click", function () { setTimeout(close, a.target === "_blank" ? 150 : 0); }); });
    var form = $("form", body); if (kind === "trade") wireTrade(form);
    if (form) wireSubmit(form, kind, vi, source, function () { body.innerHTML = successHtml(kind, false); var ok = $(".ft-ok", body); if (ok) ok.focus(); });
    modal.classList.toggle("is-trade", kind === "trade");
    var sw = innerWidth - document.documentElement.clientWidth;
    document.documentElement.classList.add("ft-modal-open"); if (sw > 0) document.body.style.paddingRight = sw + "px";
    modal.hidden = false; panel.scrollTop = 0;
    requestAnimationFrame(function () { modal.classList.add("is-in"); var x = $(".ft-modal-x", modal); if (x) x.focus({ preventScroll: true }); });
  }
  function close() {
    if (!modal || modal.hidden) return;
    modal.classList.remove("is-in"); document.documentElement.classList.remove("ft-modal-open"); document.body.style.paddingRight = "";
    setTimeout(function () { modal.hidden = true; $(".ft-modal-body", modal).innerHTML = ""; }, 220);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-ft-open]"); if (!t) return;
    var kind = t.getAttribute("data-ft-open") === "trade" ? "trade" : "financing";
    if (kind === "trade" && !CFG.trade.on) return; if (kind === "financing" && !CFG.fin.on) return;
    e.preventDefault();
    var vi = t.hasAttribute("data-ft-vehicle") ? vehicleInfo(window.FT_VEHICLE) : null;
    open(kind, vi, t.getAttribute("data-ft-source") || (vi ? "vehicle-page" : (document.body.getAttribute("data-page") || "homepage")));
  });

  /* ---------- vehicle page buttons ---------- */
  function vehicleBlock(host) {
    if (!host) return;
    var fin = CFG.fin.btns, tr = CFG.trade.btns;
    if (!fin && !tr) { host.remove(); return; }
    var grp = function (k, label, primary, call) {
      var tel = CFG[k].tel;
      return '<div class="ft-vft-grp"><p class="ft-vft-k">' + label + '</p><div class="ft-vft-row">' +
        '<button type="button" class="ft-vft-btn is-primary" data-ft-open="' + (k === "trade" ? "trade" : "financing") + '" data-ft-vehicle>' + primary + "</button>" +
        (tel ? '<a class="ft-vft-btn is-call" data-ft-call="' + k + '" href="' + esc(tel) + '">' + PHONE_SVG + "<span>" + call + "</span></a>" : "") + "</div></div>";
    };
    host.innerHTML = (fin ? grp("fin", "Financing", "Apply for Financing", "Call About Financing") : "") + (tr ? grp("trade", "Trade-in", "Value My Trade-In", "Call About Trade-In") : "");
    host.classList.toggle("is-single", !(fin && tr));
  }
  function onVehicle() { vehicleBlock(document.getElementById("ftVehicle")); }
  document.addEventListener("ft:vehicle", onVehicle);


  /* ---------- header: keep the nav bar stable as pages are added ----------
     <nav data-ft-navfit> : links that do not fit move into a "More" menu instead of
     squeezing the logo or pushing the phone number / address out of the header. */
  function navFit(nav) {
    if (nav.__ftFit) return; nav.__ftFit = true;
    var items = Array.prototype.slice.call(nav.children).filter(function (c) { return !c.classList.contains("ft-more"); });
    var more = document.createElement("div"); more.className = "ft-more"; more.hidden = true;
    more.innerHTML = '<button type="button" class="ft-more-btn" aria-expanded="false" aria-haspopup="true">' + esc(nav.getAttribute("data-ft-more") || "More") + '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button><div class="ft-more-menu" hidden></div>';
    nav.appendChild(more);
    var btn = more.firstChild, menu = more.lastChild;
    function shut() { menu.hidden = true; btn.setAttribute("aria-expanded", "false"); }
    btn.addEventListener("click", function (e) { e.stopPropagation(); var o = menu.hidden; menu.hidden = !o; btn.setAttribute("aria-expanded", String(o)); });
    document.addEventListener("click", function (e) { if (!more.contains(e.target)) shut(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") shut(); });
    var shown = function (el) { return getComputedStyle(el).display !== "none"; };
    function fit() {
      shut();
      items.forEach(function (it) { nav.insertBefore(it, more); });
      more.hidden = true;
      var cs = getComputedStyle(nav), min = Number(nav.getAttribute("data-ft-navfit-min")) || 0;
      /* mobile: the same list becomes a vertical drop-down menu, leave it alone */
      if (innerWidth < min || cs.flexDirection.indexOf("column") === 0 || cs.position === "absolute" || cs.position === "fixed") return;
      var avail = nav.clientWidth; if (!avail || !shown(nav)) return;
      var gap = parseFloat(getComputedStyle(nav).columnGap) || 0;
      var vis = items.filter(shown);
      var need = function (list, extra) { return list.reduce(function (a, el) { return a + el.getBoundingClientRect().width; }, 0) + gap * Math.max(0, list.length - 1 + (extra ? 1 : 0)) + (extra || 0); };
      if (need(vis, 0) <= avail + 1) return;
      more.hidden = false; var mw = more.getBoundingClientRect().width;
      while (vis.length > 1 && need(vis, mw) > avail + 1) { var last = vis.pop(); menu.insertBefore(last, menu.firstChild); }
    }
    var t; var later = function () { clearTimeout(t); t = setTimeout(fit, 60); };
    if (window.ResizeObserver) new ResizeObserver(later).observe(nav.parentNode || nav); else window.addEventListener("resize", later);
    window.addEventListener("load", fit); if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
    fit();
  }

  /* ---------- page init ---------- */
  /* fills call links and inline financing forms inside scope (also used by single-page themes after they draw a view) */
  function mount(scope) {
    scope = scope || document;
    fillCallLinks(scope);
    $$("[data-ft-fin-inline]", scope).forEach(function (host) {
      if (host.__ftMounted) return; host.__ftMounted = true;
      if (!CFG.fin.on || !CFG.fin.page) return;
      host.innerHTML = financingForm(null, true);
      var form = $("form", host);
      wireSubmit(form, "financing", null, "financing-page", function () { host.innerHTML = successHtml("financing", true); var ok = $(".ft-ok", host); if (ok) ok.focus(); });
    });
    var vh = $("#ftVehicle", scope); if (vh && window.FT_VEHICLE && !vh.childElementCount) onVehicle();
  }
  /* Apex Drift: the vehicle page always gets its Financing / Trade-In block, even when an
     older cached apex-pages-20261119.js draws the page without the #ftVehicle slot. */
  function vehicleFromPage(box) {
    var spec = {};
    $$(".apx-spec-item", box).forEach(function (it) {
      var k = str((it.querySelector("span") || {}).textContent).toLowerCase().replace(/[^a-z ]/g, "").trim();
      var v = str((it.querySelector("b") || {}).textContent);
      if (k && v) spec[k] = v;
    });
    var h = box.querySelector("h1") || box.querySelector("h2");
    return { id: new URLSearchParams(location.search).get("id") || "", title: h ? str(h.textContent) : "",
      year: spec.year, make: spec.make, model: spec.model, trim: spec.trim, stock: spec.stock, vin: spec.vin };
  }
  function apexVehicleFallback() {
    if (!document.querySelector('[data-apx-kind="vehicle"]')) return;
    var box = document.getElementById("apxVehicleContent"); if (!box) return;
    function ensure() {
      if (document.getElementById("ftVehicle")) return;
      var anchor = box.querySelector(".apx-spec-heading"); if (!anchor) return;
      var host = document.createElement("div");
      host.className = "ft-vft"; host.id = "ftVehicle"; host.setAttribute("aria-label", "Financing and trade-in");
      anchor.parentNode.insertBefore(host, anchor);
      if (!window.FT_VEHICLE) window.FT_VEHICLE = vehicleFromPage(box);
      onVehicle();
    }
    ensure();
    if (window.MutationObserver) new MutationObserver(ensure).observe(box, { childList: true, subtree: true });
  }
  function init() {
    enableLenderLinks();
    apexVehicleFallback();
    $$("[data-ft-navfit]").forEach(navFit);
    mount(document);
    if (window.FT_VEHICLE) onVehicle();
    /* deep link: #trade-in opens the trade-in form */
    if (/^#(trade-?in|value-my-trade)$/i.test(location.hash) && CFG.trade.on && document.querySelector('[data-ft-open="trade"]')) setTimeout(function () { open("trade", null, "homepage"); }, 400);
  }
  window.FT = { mount: mount, open: function (kind, vehicle) { open(kind === "trade" ? "trade" : "financing", vehicleInfo(vehicle), "script"); }, close: close, config: CFG };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
