/* Adds a different animated background to every section (aurora, grid, bubbles, light sweep, speed lines, rings). */
(function(){
if(window.PA_TOUCH)return; /* iOS memory guard: no animated section backgrounds on phones / tablets */
var secs=[].slice.call(document.querySelectorAll('main>section,main section.apx-content-section,footer'));
var seen=[];
function mk(c,s){var e=document.createElement('i');e.className=c;if(s)e.style.cssText=s;return e}
var R=function(a,b){return a+Math.random()*(b-a)};
var V=[
 function(g){g.appendChild(mk('o o1'));g.appendChild(mk('o o2'));g.appendChild(mk('o o3'))},
 function(g){g.appendChild(mk('o o2'));g.appendChild(mk('gr'))},
 function(g){g.appendChild(mk('o o1'));for(var i=0;i<14;i++){var s=R(10,46);g.appendChild(mk('b','left:'+R(2,96)+'%;width:'+s+'px;height:'+s+'px;animation-duration:'+R(11,24)+'s;animation-delay:'+(-R(0,20))+'s'))}},
 function(g){g.appendChild(mk('o o3'));g.appendChild(mk('o o2'));g.appendChild(mk('sw'));g.appendChild(mk('sw','animation-delay:-4.5s;width:14%'))},
 function(g){g.appendChild(mk('o o1'));for(var i=0;i<11;i++)g.appendChild(mk('sl','top:'+R(6,94)+'%;width:'+R(14,34)+'%;animation-duration:'+R(2.4,5.5)+'s;animation-delay:'+(-R(0,5))+'s;opacity:'+R(.4,.95)))},
 function(g){g.appendChild(mk('o o2'));g.appendChild(mk('rg','left:62%;top:20%;width:46vmin;height:46vmin'));g.appendChild(mk('rg','left:62%;top:20%;width:46vmin;height:46vmin;animation-delay:-4s'));g.appendChild(mk('o o3'))}
];
var io='IntersectionObserver' in window?new IntersectionObserver(function(es){es.forEach(function(e){e.target.firstChild.classList.toggle('off',!e.isIntersecting)})},{rootMargin:'200px'}):null;
var n=0;
secs.forEach(function(s){
 if(s.matches('.hero,.pin,.mq,[class*=hero],[class*=travel]')||s.querySelector('video'))return;
 var g=document.createElement('div');g.className='vbg';g.setAttribute('aria-hidden','true');V[n%V.length](g);n++;
 s.classList.add('vbg-host');s.insertBefore(g,s.firstChild);if(io)io.observe(s);
});
})();
