/* LAUNCH MODE FX: cursor glow, scroll reveal, rising embers, shooting stars. All optional, no dependencies. */
(function(){
var RM=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;
function mk(t,c){var e=document.createElement(t);if(c)e.className=c;return e}
function R(a,b){return a+Math.random()*(b-a)}
/* 1. cursor spotlight (mouse devices only) */
if(!RM&&matchMedia('(pointer:fine)').matches){
 var sp=mk('div','vx-spot');document.body.appendChild(sp);var x=0,y=0,tx=0,ty=0,run=0;
 addEventListener('pointermove',function(e){tx=e.clientX;ty=e.clientY;sp.classList.add('on');if(!run){run=1;requestAnimationFrame(tick)}},{passive:true});
 document.addEventListener('mouseleave',function(){sp.classList.remove('on')});
 function tick(){x+=(tx-x)*.14;y+=(ty-y)*.14;sp.style.transform='translate3d('+x+'px,'+y+'px,0)';if(Math.abs(tx-x)+Math.abs(ty-y)>.5)requestAnimationFrame(tick);else run=0}
}
/* 2. scroll reveal on safe, static blocks */
var sel='.why-intro,.feat-c,.brands-head,.bs-head,.loc-txt,.mapbox,.lift-top,.f-brand,.f-top>div,.apx-section-head,.apx-results-head,.apx-toolbar,.srch-h,.apx-content-section h2';
var els=[].slice.call(document.querySelectorAll(sel));
if(!RM&&'IntersectionObserver' in window&&els.length){
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('vx-in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
 els.forEach(function(el,i){el.setAttribute('data-vx','');el.style.setProperty('--vd',((i%4)*0.09)+'s');io.observe(el)});
 setTimeout(function(){els.forEach(function(el){el.classList.add('vx-in')})},6000);
}
/* 3. rising glow dots in footer, promo band, Why and location sections (desktop only: iOS memory guard) */
if(!RM&&!window.PA_TOUCH){
 var cols=['#FF6B52','#D98BE0','#7FD6FF','#FFC58A'];
 ['#foot','#lift','#why','#location','.apx-hero'].forEach(function(q){
  var host=document.querySelector(q);if(!host)return;
  if(getComputedStyle(host).position==='static')host.style.position='relative';
  var d=mk('div','vx-dots');d.setAttribute('aria-hidden','true');
  for(var i=0;i<16;i++){var p=mk('i');p.style.cssText='left:'+R(1,99)+'%;--s:'+R(4,11)+'px;--c:'+cols[i%4]+';--d:'+R(9,19)+'s;--dl:-'+R(0,16)+'s;--x:'+R(-60,60)+'px';d.appendChild(p)}
  host.insertBefore(d,host.firstChild);
 });
 /* 4. shooting stars */
 ['#foot','.vx-tunnel'].forEach(function(q){
  var host=document.querySelector(q);if(!host)return;
  if(getComputedStyle(host).position==='static')host.style.position='relative';
  for(var i=0;i<3;i++){var s=mk('span','vx-shoot');s.style.cssText='--t:'+R(4,35)+'%;--l:'+R(45,95)+'%;--dl:'+(i*2.6+R(0,2))+'s';host.appendChild(s)}
 });
}
})();
