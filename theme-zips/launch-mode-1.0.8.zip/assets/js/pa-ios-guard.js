/* pa-ios-guard.js — keeps long pages light on iPhone / iPad (all devices benefit, nothing visible changes):
   1. CSS animations inside a section pause while that section is off screen or the tab is in the background
      (class "pa-off" on the section / "pa-bg" on <html>; rules in pa-mobile-safe.css).
   2. window.paOnWidth(fn): run fn on resize only when the WIDTH really changed, at most once per 150 ms
      (iOS fires "resize" every time the address bar shows or hides while scrolling). */
(function () {
  "use strict";
  var root = document.documentElement;
  window.paOnWidth = function (fn, ms) {
    var w = innerWidth, t = 0;
    addEventListener("resize", function () { clearTimeout(t); t = setTimeout(function () { if (innerWidth !== w) { w = innerWidth; fn(); } }, ms || 150); }, { passive: true });
  };
  function bg() { root.classList.toggle("pa-bg", document.visibilityState === "hidden"); }
  document.addEventListener("visibilitychange", bg); bg();
  if (!("IntersectionObserver" in window)) return;
  function watch() {
    var list = [].slice.call(document.querySelectorAll("main > section, body > section, main > div > section, .page > section, footer, .pin"));
    if (!list.length) return;
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { e.target.classList.toggle("pa-off", !e.isIntersecting); }); }, { rootMargin: "250px 0px" });
    list.forEach(function (s) { if (!s.closest("#paDrawer")) io.observe(s); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watch); else watch();
})();
