/* pa-drawer.js — the home page side menu (drawer).
   Opens from the theme's own menu button (data-trigger) or a [data-pa-drawer-open] button. The links are copied from
   the theme's header menu each time it opens (so custom pages, dropdowns and feature switches always match), with the
   current page marked. Light: one panel + a plain dark overlay; nothing runs while it is closed. */
(function () {
  "use strict";
  var d = document.getElementById("paDrawer"); if (!d) return;
  var panel = d.querySelector(".pa-drawer-panel"), nav = d.querySelector(".pa-drawer-nav");
  var trig = d.getAttribute("data-trigger") || "", srcs = (d.getAttribute("data-src") || "header nav").split("|");
  var RM = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var opener = null, closeT = 0;
  var SKIP = /^(tel:|mailto:|sms:|javascript:)|facebook\.com|google\.[a-z.]+\/(maps|search)|maps\.google|instagram\.com/i;

  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function label(a) { return (a.getAttribute("aria-label") && !a.textContent.trim() ? a.getAttribute("aria-label") : a.textContent).replace(/\s+/g, " ").trim(); }
  function here(a) {
    var u = a.href, L = location;
    if (u === L.href) return true;
    var path = L.pathname.replace(/\/index\.html$/, "/"), up = a.pathname.replace(/\/index\.html$/, "/");
    if (a.hash && a.hash.length > 1) return up === path && a.hash === L.hash;
    return up === path && (!L.hash || L.hash === "#" || L.hash === "#/" || L.hash === "#home");
  }
  function build() {
    var links = [];
    for (var i = 0; i < srcs.length && links.length < 2; i++) {
      var box = document.querySelector(srcs[i]); if (!box) continue;
      links = [].slice.call(box.querySelectorAll("a[href]")).filter(function (a) { return !SKIP.test(a.getAttribute("href") || "") && label(a); });
    }
    var seen = {}, out = [], cur = false;
    links.forEach(function (a) {
      var t = label(a), k = (a.getAttribute("href") || "") + "|" + t.toLowerCase(); if (seen[k]) return; seen[k] = 1;
      var child = !!a.closest(".nav-dropdown,.pa-dd-menu,.pa-dd-list,[class*='dropdown'],.sub-menu,.submenu,li li");
      var on = !cur && !child && here(a); if (on) cur = true;
      out.push('<a href="' + esc(a.getAttribute("href")) + '"' + (a.target === "_blank" ? ' target="_blank" rel="noopener"' : "") + ' class="pa-drawer-link' + (child ? " is-child" : "") + '"' + (on ? ' aria-current="page"' : "") + "><span>" + esc(t) + '</span><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></a>');
    });
    if (out.length) nav.innerHTML = out.join("");
  }
  function focusables() { return [].slice.call(panel.querySelectorAll('a[href],button:not([disabled]),[tabindex="0"]')).filter(function (el) { return el.offsetParent !== null; }); }
  function open(from) {
    clearTimeout(closeT); build(); opener = from || document.activeElement;
    d.hidden = false; document.documentElement.classList.add("pa-drawer-lock");
    if (opener && opener.setAttribute) opener.setAttribute("aria-expanded", "true");
    requestAnimationFrame(function () { requestAnimationFrame(function () { d.classList.add("is-open"); var f = nav.querySelector("a") || panel; f.focus({ preventScroll: true }); }); });
  }
  function close() {
    if (d.hidden) return;
    d.classList.remove("is-open"); document.documentElement.classList.remove("pa-drawer-lock");
    if (opener && opener.setAttribute) { opener.setAttribute("aria-expanded", "false"); try { opener.focus({ preventScroll: true }); } catch (e) {} }
    closeT = setTimeout(function () { d.hidden = true; }, RM ? 0 : 340);
  }
  /* capture phase: the theme's own menu button opens this drawer instead of its old mobile menu */
  window.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest((trig ? trig + "," : "") + "[data-pa-drawer-open]");
    if (t && !d.contains(t)) { e.preventDefault(); e.stopImmediatePropagation(); if (d.hidden) open(t); else close(); return; }
    if (d.hidden) return;
    if (e.target.closest("[data-pa-close]")) { e.preventDefault(); close(); return; }
    if (e.target.closest(".pa-drawer-panel a[href]")) close();
  }, true);
  document.addEventListener("keydown", function (e) {
    if (d.hidden) return;
    if (e.key === "Escape") { e.preventDefault(); close(); return; }
    if (e.key !== "Tab") return;
    var f = focusables(); if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  addEventListener("hashchange", close);
})();
